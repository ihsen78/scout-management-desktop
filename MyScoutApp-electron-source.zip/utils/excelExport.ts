export const exportToExcel = (headers: string[], data: (string | number)[][], filename: string = 'report.xlsx') => {
  let csvContent = "data:text/csv;charset=utf-8,%EF%BB%BF"; // BOM for UTF-8 in Excel

  // Add headers
  csvContent += headers.join(',') + '\n';

  // Add data
  data.forEach(row => {
    csvContent += row.map(item => {
      // Handle commas and newlines in data by quoting
      let processedItem = String(item).replace(/"/g, '""');
      if (processedItem.includes(',') || processedItem.includes('\n')) {
        processedItem = `"${processedItem}"`;
      }
      return processedItem;
    }).join(',') + '\n';
  });

  const encodedUri = encodeURI(csvContent);
  const link = document.createElement('a');
  link.setAttribute('href', encodedUri);
  link.setAttribute('download', filename);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};