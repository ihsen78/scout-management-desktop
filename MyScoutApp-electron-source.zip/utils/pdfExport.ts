export const exportToPdf = (htmlContent: string, filename: string = 'report.pdf') => {
  const printWindow = window.open('', '', 'height=600,width=800');
  if (printWindow) {
    printWindow.document.write(`
      <html>
        <head>
          <title>${filename}</title>
          <style>
            body { font-family: 'Arial', sans-serif; margin: 20px; direction: rtl; text-align: right; }
            table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
            th, td { border: 1px solid #ccc; padding: 8px; }
            th { background-color: #f2f2f2; }
            h1, h2, h3 { color: #333; }
            @page { size: A4; margin: 2cm; }
          </style>
        </head>
        <body>
          ${htmlContent}
        </body>
      </html>
    `);
    printWindow.document.close();
    printWindow.focus();
    printWindow.print();
    // printWindow.close(); // Not always desirable to auto-close
  } else {
    alert('Failed to open print window. Please allow pop-ups for this site.');
  }
};