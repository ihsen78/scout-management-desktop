
import { AppData } from '../types';

export const loadData = (key: string, defaultData: AppData): AppData => {
  try {
    const serializedData = localStorage.getItem(key);
    if (serializedData === null) {
      return defaultData;
    }
    const parsedData = JSON.parse(serializedData);
    // Merge loaded data with defaultData to ensure new fields are present if localStorage is old
    return { ...defaultData, ...parsedData, dynamicConfig: { ...defaultData.dynamicConfig, ...parsedData.dynamicConfig } };
  } catch (error) {
    console.error("Error loading data from localStorage:", error);
    return defaultData;
  }
};

export const saveData = (key: string, data: AppData): void => {
  try {
    const serializedData = JSON.stringify(data);
    localStorage.setItem(key, serializedData);
  } catch (error) {
    console.error("Error saving data to localStorage:", error);
  }
};
