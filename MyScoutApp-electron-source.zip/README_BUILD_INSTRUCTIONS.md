
# How to Build Your Desktop App

This project was bootstrapped by Electronize AI.

## Prerequisites
- Node.js installed on your machine.

## Instructions

1. Unzip this folder.
2. Open a terminal in this folder.
3. Run `npm install` to install dependencies.
4. Run `npm start` to test the application locally.
5. Run `npm run dist` to build the final executable (.exe, .dmg, etc).

## Note
The `dist` command uses electron-builder to compile the binary for your specific OS.
