

export type Unit = string; // Now dynamic
export type SubUnit = string; // Now dynamic

export interface TrainingLogEntry {
  id: string;
  title: string;
  date: string; // YYYY-MM-DD
  description: string;
  certificateUrl?: string; // Optional URL to a certificate or proof
}

export interface Member {
  id: string;
  fullName: string;
  dateOfBirth: string; // YYYY-MM-DD
  unit: Unit;
  subUnit: SubUnit;
  trainingLevel: string; // المستوى التدريبي
  registrationYear: number;
  contactInfo: string;
  notes: string;
  badgesTimeline: string[]; // List of badge names/dates
  profilePicture?: string; // Add this line for profile pictures
  trainingLog: TrainingLogEntry[]; // New field for training log
}

export type ActivityType = string; // Now dynamic

export interface Activity {
  id: string;
  title: string;
  type: ActivityType;
  date: string; // YYYY-MM-DD
  unitInvolved: Unit[];
  supervisors: string[];
  plannedBudget: number;
  actualBudget: number;
  status: 'مخطط' | 'منفذ' | 'ملغى';
  notes: string;
  attachedDocuments: string[]; // List of document IDs or names
}

export type RevenueCategory = string; // Now dynamic
export type ExpenseCategory = string; // Now dynamic

export interface FinancialRecord {
  id: string;
  date: string; // YYYY-MM-DD
  type: 'revenue' | 'expense' | 'subscription' | 'campPayment';
  category?: RevenueCategory | ExpenseCategory; // Optional for subscription/campPayment
  description: string;
  amount: number;
  memberId?: string; // For subscriptions/camp payments
  activityId?: string; // For activity-related revenues/expenses
  scoutingYear: string; // e.g., "2023-2024"
}

export interface SubscriptionStatus {
  memberId: string;
  scoutingYear: string;
  paid: boolean;
  amount: number;
}
export type scoutingYears = string; // Now dynamic
export type DocumentType = string; // Now dynamic
export type DocumentRecipient = string; // Now dynamic

export interface Document {
  id: string;
  title: string;
  type: DocumentType;
  date: string; // YYYY-MM-DD
  recipient: DocumentRecipient; // Can be a custom string for 'Other'
  status: 'صادر' | 'وارد' | 'مسودة';
  content: string; // Actual document text/details
  archiveDate: string; // YYYY-MM-DD
  notes: string;
}

export interface Notification {
  id: number;
  message: string;
  type: 'success' | 'error' | 'info' | 'warning';
}

export interface AppData {
  members: Member[];
  activities: Activity[];
  financialRecords: FinancialRecord[];
  documents: Document[];
  dynamicConfig: {
    units: string[];
    subUnits: Record<string, string[]>; // { "الوحدة": ["الفرقة1", "الفرقة2"] }
    activityTypes: string[];
    revenueCategories: string[];
    expenseCategories: string[];
    documentTypes: string[];
    documentRecipients: string[];
    scoutingYears: string[]; // Added scoutingYears
  };
}


export const initialAppData: AppData = {
  members: [
    {
      id: 'm1', fullName: 'أحمد بن علي', dateOfBirth: '2010-03-15', unit: 'الأشبال', subUnit: 'الفل',
      trainingLevel: 'مستوى أول', registrationYear: 2023, contactInfo: '98123456', notes: 'نشيط جداً', badgesTimeline: ['شارة الصداقة (2023)'],
      profilePicture: undefined,
      trainingLog: [], // Initialize trainingLog
    },
    {
      id: 'm2', fullName: 'فاطمة الزهراء', dateOfBirth: '2009-07-22', unit: 'الزهرات', subUnit: 'الياسمين',
      trainingLevel: 'مستوى ثاني', registrationYear: 2022, contactInfo: '99876543', notes: 'قائدة مميزة', badgesTimeline: ['شارة الخدمة (2022)'],
      profilePicture: undefined,
      trainingLog: [], // Initialize trainingLog
    },
    {
      id: 'm3', fullName: 'علي الجبالي', dateOfBirth: '2005-01-01', unit: 'الكشافة', subUnit: 'فرقة حنبعل',
      trainingLevel: 'مستوى ثالث', registrationYear: 2021, contactInfo: '97112233', notes: 'مهارات قيادية', badgesTimeline: ['شارة القيادة (2021)'],
      profilePicture: undefined,
      trainingLog: [], // Initialize trainingLog
    },
    {
      id: 'm4', fullName: 'ليلى بن صالح', dateOfBirth: '2004-11-10', unit: 'المرشدات', subUnit: 'الخنساء',
      trainingLevel: 'مستوى رابع', registrationYear: 2020, contactInfo: '96554433', notes: 'منظمة ومجتهدة', badgesTimeline: ['شارة التنظيم (2020)'],
      profilePicture: undefined,
      trainingLog: [], // Initialize trainingLog
    },
    {
      id: 'm5', fullName: 'محمد الأمين', dateOfBirth: '1999-05-20', unit: 'الجوالة', subUnit: 'عشيرة حمزة',
      trainingLevel: 'قائد فوج', registrationYear: 2018, contactInfo: '95667788', notes: 'خبرة واسعة', badgesTimeline: ['شارة القائد (2019)'],
      profilePicture: undefined,
      trainingLog: [], // Initialize trainingLog
    },
    {
      id: 'm6', fullName: 'سارة التومي', dateOfBirth: '1998-09-01', unit: 'الدليلات', subUnit: 'الجازية الهلالية',
      trainingLevel: 'قائدة كشفية', registrationYear: 2017, contactInfo: '94778899', notes: 'مثابرة ومبدعة', badgesTimeline: ['شارة الإبداع (2018)'],
      profilePicture: undefined,
      trainingLog: [], // Initialize trainingLog
    },
    {
      id: 'm7', fullName: 'سامي بلحاج', dateOfBirth: '2015-02-28', unit: 'العصافير', subUnit: 'غير محدد',
      trainingLevel: 'مبتدئ', registrationYear: 2024, contactInfo: '93121212', notes: 'متحمس جديد', badgesTimeline: [],
      profilePicture: undefined,
      trainingLog: [], // Initialize trainingLog
    },
    {
      id: 'm8', fullName: 'ريم القاسم', dateOfBirth: '1985-06-05', unit: 'إطار الفوج', subUnit: 'غير محدد',
      trainingLevel: 'إطار إداري', registrationYear: 2010, contactInfo: '92343434', notes: 'مسؤولة مالية', badgesTimeline: ['شارة الإدارة (2011)'],
      profilePicture: undefined,
      trainingLog: [], // Initialize trainingLog
    },
    {
      id: 'm9', fullName: 'مراد السبوعي', dateOfBirth: '2011-04-01', unit: 'الأشبال', subUnit: 'الزياتين',
      trainingLevel: 'مستوى أول', registrationYear: 2023, contactInfo: '91565656', notes: 'يحب الأنشطة الخارجية', badgesTimeline: [],
      profilePicture: undefined,
      trainingLog: [], // Initialize trainingLog
    },
    {
      id: 'm10', fullName: 'هناء اللجمي', dateOfBirth: '2008-08-18', unit: 'الزهرات', subUnit: 'البنفسج',
      trainingLevel: 'مستوى أول', registrationYear: 2023, contactInfo: '90787878', notes: 'تحب الرسم', badgesTimeline: ['شارة الفن (2023)'],
      profilePicture: undefined,
      trainingLog: [], // Initialize trainingLog
    },
  ],
  activities: [
    {
      id: 'a1', title: 'مخيم صيفي بجبال خمير', type: 'مخيم', date: '2024-07-10', unitInvolved: ['الكشافة', 'المرشدات'],
      supervisors: ['محمد الأمين', 'سارة التومي'], plannedBudget: 1500, actualBudget: 1450, status: 'منفذ',
      notes: 'مخيم ناجح، حقق الأهداف المرجوة.', attachedDocuments: ['تقرير المخيم'],
    },
    {
      id: 'a2', title: 'رحلة استكشافية إلى غار الثور', type: 'رحلة', date: '2024-03-20', unitInvolved: ['الأشبال', 'الزهرات'],
      supervisors: ['فاطمة الزهراء'], plannedBudget: 200, actualBudget: 180, status: 'منفذ',
      notes: 'رحلة ممتعة للأطفال.', attachedDocuments: [],
    },
    {
      id: 'a3', title: 'اجتماع شهري للفوج', type: 'اجتماع محلي', date: '2024-05-05', unitInvolved: ['إطار الفوج'],
      supervisors: ['ريم القاسم'], plannedBudget: 50, actualBudget: 45, status: 'منفذ',
      notes: 'مناقشة خطة الأنشطة القادمة.', attachedDocuments: ['محضر الاجتماع'],
    },
    {
      id: 'a4', title: 'المشاركة في يوم البيئة العالمي', type: 'نشاط خارجي', date: '2024-06-05', unitInvolved: ['الكشافة', 'المرشدات', 'الجوالة', 'الدليلات'],
      supervisors: ['محمد الأمين'], plannedBudget: 100, actualBudget: 90, status: 'منفذ',
      notes: 'تنظيف الشاطئ والمشاركة في الورشات.', attachedDocuments: [],
    },
    {
      id: 'a5', title: 'مخيم الخريف في غابة بوشمة', type: 'مخيم', date: '2024-11-01', unitInvolved: ['الكشافة', 'المرشدات'],
      supervisors: ['محمد الأمين'], plannedBudget: 1200, actualBudget: 0, status: 'مخطط',
      notes: 'التحضير للمخيم جارٍ.', attachedDocuments: [],
    },
  ],
  financialRecords: [
    { id: 'f1', date: '2023-09-01', type: 'subscription', description: 'اشتراك أحمد بن علي (2023-2024)', amount: 50, memberId: 'm1', scoutingYear: '2023-2024' },
    { id: 'f2', date: '2023-09-05', type: 'subscription', description: 'اشتراك فاطمة الزهراء (2023-2024)', amount: 50, memberId: 'm2', scoutingYear: '2023-2024' },
    { id: 'f3', date: '2024-01-10', type: 'revenue', category: 'المنح', description: 'منحة من بلدية سيدي بوعلي', amount: 500, scoutingYear: '2023-2024' },
    { id: 'f4', date: '2024-01-15', type: 'expense', category: 'النقل', description: 'مصاريف نقل رحلة غار الثور', amount: 80, activityId: 'a2', scoutingYear: '2023-2024' },
    { id: 'f5', date: '2024-01-15', type: 'expense', category: 'التغذية', description: 'مصاريف تغذية رحلة غار الثور', amount: 100, activityId: 'a2', scoutingYear: '2023-2024' },
    { id: 'f6', date: '2023-09-10', type: 'subscription', description: 'اشتراك علي الجبالي (2023-2024)', amount: 50, memberId: 'm3', scoutingYear: '2023-2024' },
    { id: 'f7', date: '2023-09-12', type: 'subscription', description: 'اشتراك ليلى بن صالح (2023-2024)', amount: 50, memberId: 'm4', scoutingYear: '2023-2024' },
    { id: 'f8', date: '2024-07-01', type: 'campPayment', description: 'دفعة مخيم صيفي - م1', amount: 75, memberId: 'm1', activityId: 'a1', scoutingYear: '2023-2024' },
    { id: 'f9', date: '2024-07-01', type: 'campPayment', description: 'دفعة مخيم صيفي - م2', amount: 75, memberId: 'm2', activityId: 'a1', scoutingYear: '2023-2024' },
    { id: 'f10', date: '2024-07-01', type: 'campPayment', description: 'دفعة مخيم صيفي - م3', amount: 75, memberId: 'm3', activityId: 'a1', scoutingYear: '2023-2024' },
    { id: 'f11', date: '2024-07-05', type: 'expense', category: 'الإقامة', description: 'تكاليف إقامة مخيم صيفي', amount: 800, activityId: 'a1', scoutingYear: '2023-2024' },
    { id: 'f12', date: '2024-07-05', type: 'expense', category: 'التغذية', description: 'تكاليف تغذية مخيم صيفي', amount: 600, activityId: 'a1', scoutingYear: '2023-2024' },
  ],
  documents: [
    {
      id: 'd1', title: 'ترخيص مخيم صيفي', type: 'ترخيص مخيم', date: '2024-06-01', recipient: 'جهة سوسة للكشافة التونسية',
      status: 'صادر', content: 'تفاصيل ترخيص المخيم الصيفي في جبال خمير.', archiveDate: '2024-06-01', notes: 'تمت الموافقة.',
    },
    {
      id: 'd2', title: 'رسالة شكر', type: 'رسالة رسمية', date: '2024-06-15', recipient: 'جهة أخرى',
      status: 'صادر', content: 'رسالة شكر لبلدية سيدي بوعلي على المنحة.', archiveDate: '2024-06-15', notes: 'تم الإرسال.',
    },
    {
      id: 'd3', title: 'طلب تجديد بطاقات', type: 'طلب تجديد', date: '2024-08-01', recipient: 'جهة سوسة للكشافة التونسية',
      status: 'مسودة', content: 'طلب تجديد بطاقات عضوية للعام الكشفي الجديد.', archiveDate: '', notes: 'في انتظار المراجعة.',
    },
    {
      id: 'd4', title: 'تقرير يوم البيئة العالمي', type: 'ترخيص نشاط', date: '2024-06-10', recipient: 'قيادة فوج سيدي بوعلي',
      status: 'وارد', content: 'تقرير مفصل عن مشاركة الفوج في يوم البيئة العالمي.', archiveDate: '2024-06-10', notes: 'تمت مراجعته.',
    }
  ],
  dynamicConfig: {
    units: ['الأشبال', 'الزهرات', 'الكشافة', 'المرشدات', 'الجوالة', 'الدليلات', 'العصافير', 'الرابطة', 'إطار الفوج'],
    subUnits: {
      'الأشبال': ['الفل', 'الزياتين', 'الشحرور'],
      'الزهرات': ['الياسمين', 'البنفسج'],
      'الكشافة': ['فرقة حنبعل', 'فرقة فرج بن عامر'],
      'المرشدات': ['الخنساء', 'عليسة'],
      'الجوالة': ['عشيرة حمزة'],
      'الدليلات': ['الجازية الهلالية'],
      'العصافير': ['غير محدد'],
      'الرابطة': ['غير محدد'],
      'إطار الفوج': ['غير محدد'],
    },
    activityTypes: ['مخيم', 'رحلة', 'خرجة', 'اجتماع محلي', 'نشاط خارجي', 'أخرى'],
    revenueCategories: ['الاشتراكات', 'المنح', 'الرصيد المنقول', 'تحويلات في الحساب البريدي', 'إيداع في الحساب البريدي', 'إيداع بالصندوق', 'أخرى'],
    expenseCategories: ['النقل', 'التغذية', 'النشاط التربوي', 'منح', 'مختلفة', 'الأداء البريدي', 'الإقامة', 'التأمين والعلاج', 'لوازم كشفية', 'أي فئة يضيفها الفوج'],
    documentTypes: ['ترخيص نشاط', 'ترخيص مخيم', 'ترخيص رحلة', 'طلب موارد', 'رسالة رسمية', 'طلب تجديد', 'أخرى'],
    documentRecipients: ['جهة سوسة للكشافة التونسية', 'قيادة فوج سيدي بوعلي', 'جهة أخرى'],
    scoutingYears: ['2022-2023', '2023-2024', '2024-2025'] // Default scouting years
  }
};