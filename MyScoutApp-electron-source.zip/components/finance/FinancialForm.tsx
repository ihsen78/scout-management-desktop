
import React, { useState, useEffect, useContext } from 'react';
import { FinancialRecord, Member, Activity, RevenueCategory, ExpenseCategory } from '../../types';
import { NeumorphicModal } from '../common/NeumorphicModal';
import { NeumorphicInput } from '../common/NeumorphicInput';
import { NeumorphicSelect } from '../common/NeumorphicSelect';
import { NeumorphicButton } from '../common/NeumorphicButton';
import { AppContext } from '../../App';

interface FinancialFormProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (record: FinancialRecord) => void;
  initialData?: FinancialRecord | null;
  scoutingYear: string;
  members: Member[];
  activities: Activity[];
}

export function FinancialForm({ isOpen, onClose, onSubmit, initialData, scoutingYear, members, activities }: FinancialFormProps) {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error("FinancialForm must be used within an AppContext.Provider");
  }
  const { dynamicConfig } = context;

  const [formData, setFormData] = useState<Omit<FinancialRecord, 'id'>>({
    date: new Date().toISOString().split('T')[0],
    type: 'expense',
    category: dynamicConfig.expenseCategories[0] || '', // Default to first available expense category
    description: '',
    amount: 0,
    scoutingYear: scoutingYear,
    memberId: '',
    activityId: '',
  });

  useEffect(() => {
    if (initialData) {
      setFormData(initialData);
    } else {
      setFormData({
        date: new Date().toISOString().split('T')[0],
        type: 'expense',
        category: dynamicConfig.expenseCategories[0] || '',
        description: '',
        amount: 0,
        scoutingYear: scoutingYear,
        memberId: '',
        activityId: '',
      });
    }
  }, [initialData, isOpen, scoutingYear, dynamicConfig.expenseCategories]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value, type } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: type === 'number' ? parseFloat(value) : value,
    }));
  };

  const handleTypeChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const newType = e.target.value as FinancialRecord['type'];
    let newCategory: RevenueCategory | ExpenseCategory | undefined;

    if (newType === 'revenue') {
      newCategory = dynamicConfig.revenueCategories[0] || '';
    } else if (newType === 'expense') {
      newCategory = dynamicConfig.expenseCategories[0] || '';
    } else {
      newCategory = undefined;
    }

    setFormData((prev) => ({
      ...prev,
      type: newType,
      category: newCategory,
      memberId: (newType === 'subscription' || newType === 'campPayment') ? (members[0]?.id || '') : '',
      activityId: (newType === 'expense' || newType === 'campPayment') ? (activities[0]?.id || '') : '',
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit({ ...formData, id: initialData?.id || '' });
  };

  const typeOptions = [
    { value: 'revenue', label: 'دخل' },
    { value: 'expense', label: 'مصروف' },
    { value: 'subscription', label: 'اشتراك سنوي' },
    { value: 'campPayment', label: 'دفعة مخيم' },
  ];

  const revenueCategoryOptions = dynamicConfig.revenueCategories.map((cat) => ({ value: cat, label: cat }));
  const expenseCategoryOptions = dynamicConfig.expenseCategories.map((cat) => ({ value: cat, label: cat }));
  const memberOptions = members.map(m => ({ value: m.id, label: m.fullName }));
  const activityOptions = activities.map(a => ({ value: a.id, label: a.title }));

  return (
    <NeumorphicModal isOpen={isOpen} onClose={onClose} title={initialData ? 'تعديل سجل مالي' : 'إضافة سجل مالي جديد'}>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-gray-700 text-sm font-bold mb-2">التاريخ:</label>
          <NeumorphicInput
            type="date"
            name="date"
            value={formData.date}
            onChange={handleChange}
            required
            className="w-full"
          />
        </div>
        <div>
          <label className="block text-gray-700 text-sm font-bold mb-2">النوع:</label>
          <NeumorphicSelect
            name="type"
            options={typeOptions}
            value={formData.type}
            onChange={handleTypeChange}
            required
            className="w-full"
          />
        </div>

        {(formData.type === 'revenue' || formData.type === 'expense') && (
          <div>
            <label className="block text-gray-700 text-sm font-bold mb-2">الفئة:</label>
            <NeumorphicSelect
              name="category"
              options={formData.type === 'revenue' ? revenueCategoryOptions : expenseCategoryOptions}
              value={formData.category as string} // Cast to string as category can be union of enums
              onChange={handleChange}
              required
              className="w-full"
            />
          </div>
        )}

        {(formData.type === 'subscription' || formData.type === 'campPayment') && (
          <div>
            <label className="block text-gray-700 text-sm font-bold mb-2">العضو:</label>
            <NeumorphicSelect
              name="memberId"
              options={memberOptions}
              value={formData.memberId}
              onChange={handleChange}
              required
              className="w-full"
            />
          </div>
        )}

        {(formData.type === 'expense' || formData.type === 'campPayment') && (
          <div>
            <label className="block text-gray-700 text-sm font-bold mb-2">النشاط (اختياري):</label>
            <NeumorphicSelect
              name="activityId"
              options={[{ value: '', label: 'بدون نشاط' }, ...activityOptions]}
              value={formData.activityId}
              onChange={handleChange}
              className="w-full"
            />
          </div>
        )}

        <div>
          <label className="block text-gray-700 text-sm font-bold mb-2">الوصف:</label>
          <textarea
            name="description"
            value={formData.description}
            onChange={handleChange}
            rows={3}
            required
            className="bg-neumorphic-bg rounded-lg shadow-neumorphic-in border-transparent focus:border-neumorphic-primary focus:outline-none focus:ring-2 focus:ring-neumorphic-primary transition-all duration-200 px-3 py-2 text-gray-700 placeholder-gray-500 w-full"
          ></textarea>
        </div>
        <div>
          <label className="block text-gray-700 text-sm font-bold mb-2">المبلغ:</label>
          <NeumorphicInput
            type="number"
            name="amount"
            value={formData.amount}
            onChange={handleChange}
            step="0.01"
            required
            className="w-full"
          />
        </div>
        <div>
          <label className="block text-gray-700 text-sm font-bold mb-2">العام الكشفي:</label>
          <NeumorphicInput
            type="text"
            name="scoutingYear"
            value={formData.scoutingYear}
            readOnly
            className="w-full bg-gray-200 cursor-not-allowed"
          />
        </div>
        <div className="flex justify-end space-x-reverse space-x-2 mt-6">
          <NeumorphicButton type="submit" variant="primary">
            {initialData ? 'تعديل' : 'إضافة'}
          </NeumorphicButton>
          <NeumorphicButton type="button" variant="secondary" onClick={onClose}>
            إلغاء
          </NeumorphicButton>
        </div>
      </form>
    </NeumorphicModal>
  );
}
