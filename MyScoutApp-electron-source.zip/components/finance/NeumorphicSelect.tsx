import React from 'react';

interface CustomNeumorphicSelectProps {
  className?: string;
  options: { value: string; label: string }[];
}

export type NeumorphicSelectProps = CustomNeumorphicSelectProps & React.ComponentPropsWithoutRef<'select'>;

export function NeumorphicSelect({ className = '', options, ...props }: NeumorphicSelectProps) {
  return (
    <select
      className={`bg-neumorphic-bg rounded-lg shadow-neumorphic-in border-transparent focus:border-neumorphic-primary focus:outline-none focus:ring-2 focus:ring-neumorphic-primary transition-all duration-200 px-3 py-2 text-gray-700 appearance-none ${className}`}
      {...props}
    >
      {options.map((option) => (
        <option key={option.value} value={option.value}>
          {option.label}
        </option>
      ))}
    </select>
  );
}