
import React, { useContext, useMemo } from 'react';
import { AppContext } from '../../App';
import { Member, Activity, FinancialRecord, RevenueCategory, ExpenseCategory } from '../../types';
import { NeumorphicButton } from '../common/NeumorphicButton';
import { FinancialChart } from './FinancialChart';
import { exportToPdf } from '../../utils/pdfExport';
import { exportToExcel } from '../../utils/excelExport';

interface FinancialReportsProps {
  scoutingYear: string;
  members: Member[];
  activities: Activity[];
}

export function FinancialReports({ scoutingYear, members, activities }: FinancialReportsProps) {
  const context = useContext(AppContext);

  if (!context) {
    throw new Error("FinancialReports must be used within an AppContext.Provider");
  }

  const { financialRecords, addNotification, dynamicConfig } = context;

  const recordsForYear = useMemo(() => {
    return financialRecords.filter(record => record.scoutingYear === scoutingYear);
  }, [financialRecords, scoutingYear]);

  const totalRevenues = useMemo<number>(() => {
    return recordsForYear.filter(r => r.type === 'revenue' || r.type === 'subscription' || r.type === 'campPayment')
                         .reduce((sum: number, r) => sum + r.amount, 0);
  }, [recordsForYear]);

  const totalExpenses = useMemo<number>(() => {
    return recordsForYear.filter(r => r.type === 'expense')
                         .reduce((sum: number, r) => sum + r.amount, 0);
  }, [recordsForYear]);

  const balance = totalRevenues - totalExpenses;

  const revenueByCategory = useMemo(() => {
    const categories = dynamicConfig.revenueCategories.reduce((acc, cat) => ({ ...acc, [cat]: 0 }), {} as Record<RevenueCategory, number>);
    recordsForYear.filter(r => r.type === 'revenue').forEach(r => {
      if (r.category && categories[r.category as RevenueCategory] !== undefined) {
        categories[r.category as RevenueCategory] += r.amount;
      }
    });
    // Dynamically assign subscriptions and camp payments to the first revenue category or a specific one
    recordsForYear.filter(r => r.type === 'subscription').forEach(r => {
      // Find 'الاشتراكات' or default to the first available category
      const subCategory = dynamicConfig.revenueCategories.find(cat => cat === 'الاشتراكات') || dynamicConfig.revenueCategories[0];
      if (subCategory && categories[subCategory] !== undefined) {
        categories[subCategory] += r.amount;
      }
    });
    recordsForYear.filter(r => r.type === 'campPayment').forEach(r => {
      // Find 'الاشتراكات' or default to the first available category
      const subCategory = dynamicConfig.revenueCategories.find(cat => cat === 'الاشتراكات') || dynamicConfig.revenueCategories[0];
      if (subCategory && categories[subCategory] !== undefined) {
        categories[subCategory] += r.amount;
      }
    });
    return categories;
  }, [recordsForYear, dynamicConfig.revenueCategories]);

  const expenseByCategory = useMemo(() => {
    const categories = dynamicConfig.expenseCategories.reduce((acc, cat) => ({ ...acc, [cat]: 0 }), {} as Record<ExpenseCategory, number>);
    recordsForYear.filter(r => r.type === 'expense').forEach(r => {
      if (r.category && categories[r.category as ExpenseCategory] !== undefined) {
        categories[r.category as ExpenseCategory] += r.amount;
      }
    });
    return categories;
  }, [recordsForYear, dynamicConfig.expenseCategories]);

  const generateReportHtml = () => {
    let html = `
      <div style="font-family: Arial, sans-serif; direction: rtl; text-align: right; padding: 20px;">
        <h1 style="text-align: center; color: #6a82fb;">تقرير مالي للعام الكشفي ${scoutingYear}</h1>
        <p style="text-align: center; color: #555;">تاريخ التقرير: ${new Date().toLocaleDateString('ar-TN')}</p>
        <hr style="margin: 20px 0; border: 0; border-top: 1px solid #eee;">

        <h2 style="color: #6a82fb;">ملخص مالي</h2>
        <table style="width:100%; border-collapse: collapse; margin-bottom: 20px;">
          <tr><td style="padding: 8px; border: 1px solid #ddd;">إجمالي المداخيل:</td><td style="padding: 8px; border: 1px solid #ddd; text-align: left;">${totalRevenues.toFixed(2)} د.ت</td></tr>
          <tr><td style="padding: 8px; border: 1px solid #ddd;">إجمالي المصاريف:</td><td style="padding: 8px; border: 1px solid #ddd; text-align: left;">${totalExpenses.toFixed(2)} د.ت</td></tr>
          <tr><td style="padding: 8px; border: 1px solid #ddd; font-weight: bold;">الرصيد:</td><td style="padding: 8px; border: 1px solid #ddd; text-align: left; font-weight: bold; color: ${balance >= 0 ? 'green' : 'red'};">${balance.toFixed(2)} د.ت</td></tr>
        </table>

        <h2 style="color: #6a82fb;">المداخيل حسب الفئة</h2>
        <table style="width:100%; border-collapse: collapse; margin-bottom: 20px;">
          <thead>
            <tr style="background-color: #f2f2f2;">
              <th scope="col" style="padding: 8px; border: 1px solid #ddd; text-align: right;">الفئة</th>
              <th scope="col" style="padding: 8px; border: 1px solid #ddd; text-align: left;">المبلغ (د.ت)</th>
            </tr>
          </thead>
          <tbody>
            ${Object.entries(revenueByCategory).filter(([, amount]) => amount > 0).map(([cat, amount]) => `
              <tr>
                <td style="padding: 8px; border: 1px solid #ddd;">${cat}</td>
                <td style="padding: 8px; border: 1px solid #ddd; text-align: left;">${(amount as number).toFixed(2)}</td>
              </tr>
            `).join('')}
          </tbody>
        </table>

        <h2 style="color: #6a82fb;">المصاريف حسب الفئة</h2>
        <table style="width:100%; border-collapse: collapse; margin-bottom: 20px;">
          <thead>
            <tr style="background-color: #f2f2f2;">
              <th scope="col" style="padding: 8px; border: 1px solid #ddd; text-align: right;">الفئة</th>
              <th scope="col" style="padding: 8px; border: 1px solid #ddd; text-align: left;">المبلغ (د.ت)</th>
            </tr>
          </thead>
          <tbody>
            ${Object.entries(expenseByCategory).filter(([, amount]) => amount > 0).map(([cat, amount]) => `
              <tr>
                <td style="padding: 8px; border: 1px solid #ddd;">${cat}</td>
                <td style="padding: 8px; border: 1px solid #ddd; text-align: left;">${(amount as number).toFixed(2)}</td>
              </tr>
            `).join('')}
          </tbody>
        </table>

        <h2 style="color: #6a82fb;">تفاصيل السجلات المالية (${scoutingYear})</h2>
        <table style="width:100%; border-collapse: collapse; margin-bottom: 20px;">
            <thead>
              <tr style="background-color: #f2f2f2;">
                <th scope="col" style="padding: 8px; border: 1px solid #ddd; text-align: right;">التاريخ</th>
                <th scope="col" style="padding: 8px; border: 1px solid #ddd; text-align: right;">النوع</th>
                <th scope="col" style="padding: 8px; border: 1px solid #ddd; text-align: right;">الفئة</th>
                <th scope="col" style="padding: 8px; border: 1px solid #ddd; text-align: right;">الوصف</th>
                <th scope="col" style="padding: 8px; border: 1px solid #ddd; text-align: right;">المبلغ</th>
                <th scope="col" style="padding: 8px; border: 1px solid #ddd; text-align: right;">العضو/النشاط</th>
              </tr>
            </thead>
            <tbody>
              ${recordsForYear.length === 0 ? `
                <tr><td colSpan="6" style="padding: 8px; border: 1px solid #ddd; text-align: center; color: #888;">لا توجد سجلات مالية للعام الكشفي المحدد.</td></tr>
              ` : recordsForYear.map((record) => `
                  <tr>
                    <td style="padding: 8px; border: 1px solid #ddd; text-align: right;">${record.date}</td>
                    <td style="padding: 8px; border: 1px solid #ddd; text-align: right;">
                      ${record.type === 'revenue' ? 'دخل' : (record.type === 'expense' ? 'مصروف' : (record.type === 'subscription' ? 'اشتراك' : 'دفعة مخيم'))}
                    </td>
                    <td style="padding: 8px; border: 1px solid #ddd; text-align: right;">${record.category || '-'}</td>
                    <td style="padding: 8px; border: 1px solid #ddd; text-align: right;">${record.description}</td>
                    <td style="padding: 8px; border: 1px solid #ddd; text-align: right; color: ${record.type === 'revenue' || record.type === 'subscription' || record.type === 'campPayment' ? 'green' : 'red'};">
                      ${record.amount.toFixed(2)} د.ت</td>
                    <td style="padding: 8px; border: 1px solid #ddd; text-align: right;">
                      ${(record.memberId && members.find(m => m.id === record.memberId)?.fullName) ||
                       (record.activityId && activities.find(a => a.id === record.activityId)?.title) || '-'}
                    </td>
                  </tr>
                `).join('')}
            </tbody>
        </table>
      </div>
    `;
    return html;
  };

  const handleExportPdf = () => {
    const htmlContent = generateReportHtml();
    exportToPdf(htmlContent, `تقرير-مالي-${scoutingYear}-الكشافة-التونسية.pdf`);
    addNotification({ type: 'success', message: `تم تصدير التقرير المالي لـ ${scoutingYear} إلى PDF.` });
  };

  const handleExportExcel = () => {
    const headers = ['التاريخ', 'النوع', 'الفئة', 'الوصف', 'المبلغ (د.ت)', 'العام الكشفي', 'العضو/النشاط'];
    const data = recordsForYear.map(r => [
      r.date,
      r.type === 'revenue' ? 'دخل' : (r.type === 'expense' ? 'مصروف' : (r.type === 'subscription' ? 'اشتراك' : 'دفعة مخيم')),
      r.category || '',
      r.description,
      r.amount.toFixed(2),
      r.scoutingYear,
      (r.memberId && members.find(m => m.id === r.memberId)?.fullName) || (r.activityId && activities.find(a => a.id === r.activityId)?.title) || '-',
    ]);
    exportToExcel(headers, data, `تقرير-مالي-${scoutingYear}-الكشافة-التونسية.xlsx`);
    addNotification({ type: 'success', message: `تم تصدير التقرير المالي لـ ${scoutingYear} إلى Excel.` });
  };


  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <div className="bg-neumorphic-bg rounded-lg p-4 text-center shadow-neumorphic-out">
          <p className="font-semibold text-gray-700">إجمالي المداخيل:</p>
          <p className="text-3xl font-bold text-green-600">{totalRevenues.toFixed(2)} د.ت</p>
        </div>
        <div className="bg-neumorphic-bg rounded-lg p-4 text-center shadow-neumorphic-out">
          <p className="font-semibold text-gray-700">إجمالي المصاريف:</p>
          <p className="text-3xl font-bold text-red-600">{totalExpenses.toFixed(2)} د.ت</p>
        </div>
        <div className="bg-neumorphic-bg rounded-lg p-4 text-center shadow-neumorphic-out">
          <p className="font-semibold text-gray-700">الرصيد:</p>
          <p className={`text-3xl font-bold ${balance >= 0 ? 'text-blue-600' : 'text-red-600'}`}>
            {balance.toFixed(2)} د.ت
          </p>
        </div>
      </div>

      <div className="flex justify-center space-x-reverse space-x-4 mb-6">
        <NeumorphicButton onClick={handleExportPdf} variant="secondary" className="min-w-[120px]" type="button">
          تصدير PDF
        </NeumorphicButton>
        <NeumorphicButton onClick={handleExportExcel} variant="secondary" className="min-w-[120px]" type="button">
          تصدير Excel
        </NeumorphicButton>
      </div>

      <div className="bg-neumorphic-bg rounded-lg shadow-neumorphic-out p-6 mb-6">
        <h3 className="font-bold text-xl text-neumorphic-primary mb-4 text-center">المداخيل والمصاريف حسب الفئة</h3>
        <FinancialChart
          revenues={revenueByCategory}
          expenses={expenseByCategory}
        />
      </div>

      <div className="bg-neumorphic-bg rounded-lg shadow-neumorphic-out p-6">
        <h3 className="font-bold text-xl text-neumorphic-primary mb-4">تفاصيل السجلات المالية ({scoutingYear})</h3>
        <div className="overflow-x-auto">
          <table className="min-w-full bg-white rounded-lg shadow-md overflow-hidden text-right">
            <thead className="bg-gray-100">
              <tr>
                <th scope="col" className="py-2 px-4 border-b">التاريخ</th>
                <th scope="col" className="py-2 px-4 border-b">النوع</th>
                <th scope="col" className="py-2 px-4 border-b">الفئة</th>
                <th scope="col" className="py-2 px-4 border-b">الوصف</th>
                <th scope="col" className="py-2 px-4 border-b">المبلغ</th>
                <th scope="col" className="py-2 px-4 border-b">العضو/النشاط</th>
              </tr>
            </thead>
            <tbody>
              {recordsForYear.length === 0 ? (
                <tr><td colSpan={6} className="text-center py-4 text-gray-600">لا توجد سجلات مالية للعام الكشفي المحدد.</td></tr>
              ) : (
                recordsForYear.map((record) => (
                  <tr key={record.id} className="hover:bg-gray-50">
                    <td className="py-2 px-4 border-b text-gray-700">{record.date}</td>
                    <td className="py-2 px-4 border-b text-gray-700">
                      {record.type === 'revenue' ? 'دخل' : (record.type === 'expense' ? 'مصروف' : (record.type === 'subscription' ? 'اشتراك' : 'دفعة مخيم'))}
                    </td>
                    <td className="py-2 px-4 border-b text-gray-700">{record.category || '-'}</td>
                    <td className="py-2 px-4 border-b text-gray-700">{record.description}</td>
                    <td className="py-2 px-4 border-b font-semibold text-lg text-gray-700">
                      <span className={record.type === 'revenue' || record.type === 'subscription' || record.type === 'campPayment' ? 'text-green-600' : 'text-red-600'}>
                        {record.amount.toFixed(2)} د.ت
                      </span>
                    </td>
                    <td className="py-2 px-4 border-b text-gray-700">
                      {(record.memberId && members.find(m => m.id === record.memberId)?.fullName) ||
                       (record.activityId && activities.find(a => a.id === record.activityId)?.title) || '-'}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
