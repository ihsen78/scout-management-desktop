
import React, { useState, useContext, useMemo } from 'react';
import { AppContext, AppContextType } from '../../App';
import { NeumorphicButton } from '../common/NeumorphicButton';
import { NeumorphicInput } from '../common/NeumorphicInput';
import { NeumorphicSelect } from '../common/NeumorphicSelect';
import { FinancialRecord, Unit, RevenueCategory, ExpenseCategory } from '../../types';
import { FinancialForm } from './FinancialForm';
import { FinancialReports } from './FinancialReports';
import { generateUniqueId } from '../../utils/idGenerator';
import { exportToPdf } from '../../utils/pdfExport';
import { exportToExcel } from '../../utils/excelExport';

type FinancialTab = 'subscriptions' | 'campsPayments' | 'revenues' | 'expenses' | 'reports';

export function FinancialManagement() {
  const context = useContext(AppContext);
  const [activeTab, setActiveTab] = useState<FinancialTab>('subscriptions');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingRecord, setEditingRecord] = useState<FinancialRecord | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterYear, setFilterYear] = useState(new Date().getFullYear().toString());
  const [filterUnit, setFilterUnit] = useState<Unit | ''>(''); // For subscriptions/camps

  if (!context) {
    throw new Error("FinancialManagement must be used within an AppContext.Provider");
  }

  const { financialRecords, setFinancialRecords, members, activities, addNotification, isAdmin, dynamicConfig } = context as AppContextType;

  const scoutingYears = useMemo(() => {
    const years = new Set<string>();
    const currentYear = new Date().getFullYear();
    for (let i = currentYear - 2; i <= currentYear + 1; i++) {
      years.add(`${i}-${i + 1}`);
    }
    financialRecords.forEach(record => years.add(record.scoutingYear));
    return Array.from(years).sort().reverse();
  }, [financialRecords]);

  // Current scouting year calculation
  useMemo(() => {
    const today = new Date();
    const currentMonth = today.getMonth() + 1; // January is 1
    const year = today.getFullYear();
    // Assuming scouting year starts in September (month 9)
    const newScoutingYear = currentMonth >= 9 ? `${year}-${year + 1}` : `${year - 1}-${year}`;
    setFilterYear(newScoutingYear); // Set default filter year
  }, []); // eslint-disable-line react-hooks/exhaustive-deps


  const handleAddOrUpdateRecord = (newRecord: FinancialRecord) => {
    if (editingRecord) {
      setFinancialRecords(financialRecords.map((r) => (r.id === newRecord.id ? newRecord : r)));
      addNotification({ type: 'success', message: 'تم تحديث السجل المالي بنجاح.' });
    } else {
      setFinancialRecords([...financialRecords, { ...newRecord, id: generateUniqueId() }]);
      addNotification({ type: 'success', message: 'تمت إضافة سجل مالي جديد بنجاح.' });
    }
    setIsModalOpen(false);
    setEditingRecord(null);
  };

  const handleDeleteRecord = (id: string) => {
    if (!isAdmin) {
      addNotification({ type: 'error', message: 'ليس لديك صلاحية لحذف السجلات المالية.' });
      return;
    }
    if (window.confirm('هل أنت متأكد من حذف هذا السجل المالي؟')) {
      setFinancialRecords(financialRecords.filter((r) => r.id !== id));
      addNotification({ type: 'success', message: 'تم حذف السجل المالي بنجاح.' });
    }
  };

  const openEditModal = (record: FinancialRecord) => {
    if (!isAdmin) {
      addNotification({ type: 'error', message: 'ليس لديك صلاحية لتعديل السجلات المالية.' });
      return;
    }
    setEditingRecord(record);
    setIsModalOpen(true);
  };

  const filteredRecords = useMemo(() => {
    return financialRecords.filter(record => {
      const matchesSearch = record.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
                            (record.category && record.category.toLowerCase().includes(searchTerm.toLowerCase())) ||
                            (record.memberId && members.find(m => m.id === record.memberId)?.fullName.toLowerCase().includes(searchTerm.toLowerCase())) ||
                            (record.activityId && activities.find(a => a.id === record.activityId)?.title.toLowerCase().includes(searchTerm.toLowerCase()));
      const matchesYear = record.scoutingYear === filterYear;
      const matchesUnit = filterUnit === '' || (
        record.memberId && members.find(m => m.id === record.memberId)?.unit === filterUnit
      );
      return matchesSearch && matchesYear && matchesUnit;
    });
  }, [financialRecords, searchTerm, filterYear, filterUnit, members, activities]);

  const unitOptions = [{ value: '', label: 'جميع الوحدات' }, ...dynamicConfig.units.map((unit) => ({ value: unit, label: unit }))];

  const handleExportPdf = (records: FinancialRecord[], title: string) => {
    if (records.length === 0) {
      addNotification({ type: 'warning', message: 'لا توجد بيانات لتصديرها إلى PDF.' });
      return;
    }
  
    let htmlContent = `
      <div style="font-family: Arial, sans-serif; direction: rtl; text-align: right; padding: 20px;">
        <h1 style="text-align: center; color: #6a82fb;">${title} للعام الكشفي ${filterYear}</h1>
        <p style="text-align: center; color: #555;">تاريخ التقرير: ${new Date().toLocaleDateString('ar-TN')}</p>
        <hr style="margin: 20px 0; border: 0; border-top: 1px solid #eee;">
    `;
    
    htmlContent += `<table style="width:100%; border-collapse: collapse; margin-bottom: 20px;">
                      <thead>
                        <tr style="background-color: #f2f2f2;">
                          <th scope="col" style="padding: 8px; border: 1px solid #ddd; text-align: right;">التاريخ</th>
                          <th scope="col" style="padding: 8px; border: 1px solid #ddd; text-align: right;">الوصف</th>
                          <th scope="col" style="padding: 8px; border: 1px solid #ddd; text-align: right;">المبلغ</th>
                          <th scope="col" style="padding: 8px; border: 1px solid #ddd; text-align: right;">الفئة</th>
                          <th scope="col" style="padding: 8px; border: 1px solid #ddd; text-align: right;">العضو</th>
                          <th scope="col" style="padding: 8px; border: 1px solid #ddd; text-align: right;">النشاط</th>
                        </tr>
                      </thead>
                      <tbody>`;
    records.forEach(record => {
      const memberName = record.memberId ? members.find(m => m.id === record.memberId)?.fullName : '';
      const activityName = record.activityId ? activities.find(a => a.id === record.activityId)?.title : '';
      htmlContent += `<tr>
                        <td style="padding: 8px; border: 1px solid #ddd; text-align: right;">${record.date}</td>
                        <td style="padding: 8px; border: 1px solid #ddd; text-align: right;">${record.description}</td>
                        <td style="padding: 8px; border: 1px solid #ddd; text-align: right;">${record.amount.toFixed(2)} د.ت</td>
                        <td style="padding: 8px; border: 1px solid #ddd; text-align: right;">${record.category || '-'}</td>
                        <td style="padding: 8px; border: 1px solid #ddd; text-align: right;">${memberName || '-'}</td>
                        <td style="padding: 8px; border: 1px solid #ddd; text-align: right;">${activityName || '-'}</td>
                      </tr>`;
    });
    htmlContent += `</tbody></table></div>`;
    exportToPdf(htmlContent, `${title}-${filterYear}-الكشافة-التونسية.pdf`);
    addNotification({ type: 'success', message: `تم تصدير ${title} إلى PDF.` });
  };
  
  const handleExportExcel = (records: FinancialRecord[], title: string) => {
    if (records.length === 0) {
      addNotification({ type: 'warning', message: 'لا توجد بيانات لتصديرها إلى Excel.' });
      return;
    }
  
    const headers = ['التاريخ', 'الوصف', 'المبلغ (د.ت)', 'النوع', 'الفئة', 'العضو', 'النشاط', 'العام الكشفي'];
    const data = records.map(record => [
      record.date,
      record.description,
      record.amount.toFixed(2),
      record.type === 'revenue' ? 'دخل' : (record.type === 'expense' ? 'مصروف' : (record.type === 'subscription' ? 'اشتراك' : 'دفعة مخيم')),
      record.category || '',
      record.memberId ? members.find(m => m.id === record.memberId)?.fullName || '' : '',
      record.activityId ? activities.find(a => a.id === record.activityId)?.title || '' : '',
      record.scoutingYear,
    ]);
    exportToExcel(headers, data, `${title}-${filterYear}-الكشافة-التونسية.xlsx`);
    addNotification({ type: 'success', message: `تم تصدير ${title} إلى Excel.` });
  };

  // Render functions for each tab
  const renderSubscriptions = () => {
    const currentYearMembers = members.filter(m => m.registrationYear <= parseInt(filterYear.split('-')[0]) + 1);

    const membersWithSubscriptionStatus = currentYearMembers.map(member => {
      const hasPaid = financialRecords.some(r =>
        r.type === 'subscription' && r.memberId === member.id && r.scoutingYear === filterYear && r.amount > 0
      );
      const memberUnitMatchesFilter = filterUnit === '' || member.unit === filterUnit;
      return { member, hasPaid, memberUnitMatchesFilter };
    }).filter(item => item.memberUnitMatchesFilter && item.member.fullName.toLowerCase().includes(searchTerm.toLowerCase()));

    const totalPaid = membersWithSubscriptionStatus.filter(m => m.hasPaid).length;
    const totalUnpaid = membersWithSubscriptionStatus.filter(m => !m.hasPaid).length;
    const totalAmountPaid = financialRecords
      .filter(r => r.type === 'subscription' && r.scoutingYear === filterYear && membersWithSubscriptionStatus.some(m => m.member.id === r.memberId))
      .reduce((sum: number, r) => sum + r.amount, 0);

    const initialUnitTotals = dynamicConfig.units.reduce((acc, unit) => {
      acc[unit as Unit] = { paid: 0, unpaid: 0, totalAmount: 0 };
      return acc;
    }, {} as Record<Unit, { paid: number; unpaid: number; totalAmount: number }>);
    
    const unitTotals: Record<Unit, { paid: number; unpaid: number; totalAmount: number }> = { ...initialUnitTotals };

    membersWithSubscriptionStatus.forEach(item => {
      const unit = item.member.unit;
      if (unitTotals[unit]) {
        if (item.hasPaid) unitTotals[unit].paid++;
        else unitTotals[unit].unpaid++;
        const memberPayments = financialRecords.filter(r =>
          r.type === 'subscription' && r.memberId === item.member.id && r.scoutingYear === filterYear
        ).reduce((sum: number, r) => sum + r.amount, 0);
        unitTotals[unit].totalAmount += memberPayments;
      }
    });

    const subscriptionRecords = filteredRecords.filter(r => r.type === 'subscription');

    return (
      <div className="space-y-4">
        <div className="flex justify-end space-x-reverse space-x-2 mb-4">
          <NeumorphicButton onClick={() => handleExportPdf(subscriptionRecords, 'الإنخراطات السنوية')} variant="secondary" className="text-sm" type="button">
            تصدير PDF
          </NeumorphicButton>
          <NeumorphicButton onClick={() => handleExportExcel(subscriptionRecords, 'الإنخراطات السنوية')} variant="secondary" className="text-sm" type="button">
            تصدير Excel
          </NeumorphicButton>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
          <div className="bg-green-100 rounded-lg p-3 text-center shadow-inner">
            <p className="font-semibold text-green-700">المدفوعة:</p>
            <p className="text-2xl font-bold text-green-900">{totalPaid}</p>
          </div>
          <div className="bg-red-100 rounded-lg p-3 text-center shadow-inner">
            <p className="font-semibold text-red-700">غير المدفوعة:</p>
            <p className="text-2xl font-bold text-red-900">{totalUnpaid}</p>
          </div>
          <div className="bg-blue-100 rounded-lg p-3 text-center shadow-inner">
            <p className="font-semibold text-blue-700">المبلغ الإجمالي:</p>
            <p className="text-2xl font-bold text-blue-900">{totalAmountPaid.toFixed(2)} د.ت</p>
          </div>
        </div>

        <h4 className="font-semibold text-lg text-gray-700 mb-2">إجمالي الاشتراكات حسب الوحدة:</h4>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
          {Object.entries(unitTotals).map(([unit, totals]) => (
            <div key={unit} className="bg-neumorphic-bg rounded-lg shadow-neumorphic-out p-3">
              <p className="font-bold text-neumorphic-primary mb-1">{unit}</p>
              <p className="text-sm text-green-700">مدفوعة: {totals.paid}</p>
              <p className="text-sm text-red-700">غير مدفوعة: {totals.unpaid}</p>
              <p className="text-sm text-blue-700">المجموع: {totals.totalAmount.toFixed(2)} د.ت</p>
            </div>
          ))}
        </div>

        <h3 className="font-semibold text-xl mb-4 text-neumorphic-primary">قائمة الأعضاء وحالة الاشتراكات:</h3>
        <div className="overflow-x-auto">
          <table className="min-w-full bg-white rounded-lg shadow-md overflow-hidden text-right">
            <thead className="bg-gray-100">
              <tr>
                <th scope="col" className="py-2 px-4 border-b">الاسم الكامل</th>
                <th scope="col" className="py-2 px-4 border-b">الوحدة</th>
                <th scope="col" className="py-2 px-4 border-b">حالة الدفع</th>
                <th scope="col" className="py-2 px-4 border-b">المبلغ المدفوع</th>
                <th scope="col" className="py-2 px-4 border-b">الإجراءات</th>
              </tr>
            </thead>
            <tbody>
              {membersWithSubscriptionStatus.map(({ member, hasPaid }) => (
                <tr key={member.id} className="hover:bg-gray-50">
                  <td className="py-2 px-4 border-b text-gray-700">{member.fullName}</td>
                  <td className="py-2 px-4 border-b text-gray-700">{member.unit}</td>
                  <td className="py-2 px-4 border-b">
                    <span className={`px-2 py-1 rounded-full text-xs font-semibold ${hasPaid ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                      {hasPaid ? 'مدفوعة' : 'غير مدفوعة'}
                    </span>
                  </td>
                  <td className="py-2 px-4 border-b text-gray-700">
                    {financialRecords
                      .filter(r => r.type === 'subscription' && r.memberId === member.id && r.scoutingYear === filterYear)
                      .reduce((sum: number, r) => sum + r.amount, 0).toFixed(2)} د.ت
                  </td>
                  <td className="py-2 px-4 border-b">
                    {isAdmin && (
                      <NeumorphicButton
                        variant="secondary"
                        className="text-xs py-1 px-2"
                        onClick={() => {
                          const existingRecord = financialRecords.find(r => r.type === 'subscription' && r.memberId === member.id && r.scoutingYear === filterYear);
                          setEditingRecord(existingRecord || {
                            id: '',
                            date: new Date().toISOString().split('T')[0],
                            type: 'subscription',
                            description: `اشتراك ${member.fullName} (${filterYear})`,
                            amount: 50, // Default subscription amount
                            memberId: member.id,
                            scoutingYear: filterYear,
                          });
                          setIsModalOpen(true);
                        }}
                        type="button"
                      >
                        {hasPaid ? 'تعديل الدفع' : 'تسجيل دفع'}
                      </NeumorphicButton>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    );
  };

  const renderCampsPayments = () => {
    const campPayments = filteredRecords.filter(r => r.type === 'campPayment');
    return (
      <div className="space-y-4">
        <div className="flex justify-end space-x-reverse space-x-2 mb-4">
          <NeumorphicButton onClick={() => handleExportPdf(campPayments, 'اشتراكات المخيمات')} variant="secondary" className="text-sm" type="button">
            تصدير PDF
          </NeumorphicButton>
          <NeumorphicButton onClick={() => handleExportExcel(campPayments, 'اشتراكات المخيمات')} variant="secondary" className="text-sm" type="button">
            تصدير Excel
          </NeumorphicButton>
        </div>
        <h3 className="font-semibold text-xl mb-4 text-neumorphic-primary">سداد المخيمات والرحلات:</h3>
        <div className="overflow-x-auto">
          <table className="min-w-full bg-white rounded-lg shadow-md overflow-hidden text-right">
            <thead className="bg-gray-100">
              <tr>
                <th scope="col" className="py-2 px-4 border-b">التاريخ</th>
                <th scope="col" className="py-2 px-4 border-b">الوصف</th>
                <th scope="col" className="py-2 px-4 border-b">المبلغ</th>
                <th scope="col" className="py-2 px-4 border-b">العضو</th>
                <th scope="col" className="py-2 px-4 border-b">النشاط</th>
                <th scope="col" className="py-2 px-4 border-b">الإجراءات</th>
              </tr>
            </thead>
            <tbody>
              {campPayments.length === 0 ? (
                <tr><td colSpan={6} className="text-center py-4 text-gray-600">لا توجد مدفوعات مخيمات للعام الكشفي المحدد.</td></tr>
              ) : (
                campPayments.map((record) => (
                  <tr key={record.id} className="hover:bg-gray-50">
                    <td className="py-2 px-4 border-b text-gray-700">{record.date}</td>
                    <td className="py-2 px-4 border-b text-gray-700">{record.description}</td>
                    <td className="py-2 px-4 border-b text-gray-700">{record.amount.toFixed(2)} د.ت</td>
                    <td className="py-2 px-4 border-b text-gray-700">{members.find(m => m.id === record.memberId)?.fullName || 'غير معروف'}</td>
                    <td className="py-2 px-4 border-b text-gray-700">{activities.find(a => a.id === record.activityId)?.title || 'غير معروف'}</td>
                    <td className="py-2 px-4 border-b">
                      {isAdmin && (
                        <div className="flex space-x-reverse space-x-2">
                          <NeumorphicButton variant="secondary" className="text-xs py-1 px-2" onClick={() => openEditModal(record)} type="button">تعديل</NeumorphicButton>
                          <NeumorphicButton variant="danger" className="text-xs py-1 px-2" onClick={() => handleDeleteRecord(record.id)} type="button">حذف</NeumorphicButton>
                        </div>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
        {isAdmin && (
           <React.Fragment>
            <div className="flex justify-end mt-4">
              <NeumorphicButton onClick={() => {
                setEditingRecord({
                  id: '', date: new Date().toISOString().split('T')[0], type: 'campPayment',
                  description: '', amount: 0, memberId: '', activityId: '', scoutingYear: filterYear,
                });
                setIsModalOpen(true);
              }} type="button">
                إضافة دفعة مخيم
              </NeumorphicButton>
            </div>
           </React.Fragment>
        )}
      </div>
    );
  };

  const renderRevenues = () => {
    const revenues = filteredRecords.filter(r => r.type === 'revenue');
    return (
      <div className="space-y-4">
        <div className="flex justify-end space-x-reverse space-x-2 mb-4">
          <NeumorphicButton onClick={() => handleExportPdf(revenues, 'المداخيل')} variant="secondary" className="text-sm" type="button">
            تصدير PDF
          </NeumorphicButton>
          <NeumorphicButton onClick={() => handleExportExcel(revenues, 'المداخيل')} variant="secondary" className="text-sm" type="button">
            تصدير Excel
          </NeumorphicButton>
        </div>
        <h3 className="font-semibold text-xl mb-4 text-neumorphic-primary">المداخيل:</h3>
        <div className="overflow-x-auto">
          <table className="min-w-full bg-white rounded-lg shadow-md overflow-hidden text-right">
            <thead className="bg-gray-100">
              <tr>
                <th scope="col" className="py-2 px-4 border-b">التاريخ</th>
                <th scope="col" className="py-2 px-4 border-b">الفئة</th>
                <th scope="col" className="py-2 px-4 border-b">الوصف</th>
                <th scope="col" className="py-2 px-4 border-b">المبلغ</th>
                <th scope="col" className="py-2 px-4 border-b">الإجراءات</th>
              </tr>
            </thead>
            <tbody>
              {revenues.length === 0 ? (
                <tr><td colSpan={5} className="text-center py-4 text-gray-600">لا توجد مداخيل للعام الكشفي المحدد.</td></tr>
              ) : (
                revenues.map((record) => (
                  <tr key={record.id} className="hover:bg-gray-50">
                    <td className="py-2 px-4 border-b text-gray-700">{record.date}</td>
                    <td className="py-2 px-4 border-b text-gray-700">{record.category}</td>
                    <td className="py-2 px-4 border-b text-gray-700">{record.description}</td>
                    <td className="py-2 px-4 border-b text-green-700 font-semibold">{record.amount.toFixed(2)} د.ت</td>
                    <td className="py-2 px-4 border-b">
                      {isAdmin && (
                        <div className="flex space-x-reverse space-x-2">
                          <NeumorphicButton variant="secondary" className="text-xs py-1 px-2" onClick={() => openEditModal(record)} type="button">تعديل</NeumorphicButton>
                          <NeumorphicButton variant="danger" className="text-xs py-1 px-2" onClick={() => handleDeleteRecord(record.id)} type="button">حذف</NeumorphicButton>
                        </div>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
        {isAdmin && (
           <React.Fragment>
            <div className="flex justify-end mt-4">
              <NeumorphicButton onClick={() => {
                setEditingRecord({
                  id: '', date: new Date().toISOString().split('T')[0], type: 'revenue',
                  category: dynamicConfig.revenueCategories[0], description: '', amount: 0, scoutingYear: filterYear,
                });
                setIsModalOpen(true);
              }} type="button">
                إضافة دخل
              </NeumorphicButton>
            </div>
           </React.Fragment>
        )}
      </div>
    );
  };

  const renderExpenses = () => {
    const expenses = filteredRecords.filter(r => r.type === 'expense');
    return (
      <div className="space-y-4">
        <div className="flex justify-end space-x-reverse space-x-2 mb-4">
          <NeumorphicButton onClick={() => handleExportPdf(expenses, 'المصاريف')} variant="secondary" className="text-sm" type="button">
            تصدير PDF
          </NeumorphicButton>
          <NeumorphicButton onClick={() => handleExportExcel(expenses, 'المصاريف')} variant="secondary" className="text-sm" type="button">
            تصدير Excel
          </NeumorphicButton>
        </div>
        <h3 className="font-semibold text-xl mb-4 text-neumorphic-primary">المصاريف:</h3>
        <div className="overflow-x-auto">
          <table className="min-w-full bg-white rounded-lg shadow-md overflow-hidden text-right">
            <thead className="bg-gray-100">
              <tr>
                <th scope="col" className="py-2 px-4 border-b">التاريخ</th>
                <th scope="col" className="py-2 px-4 border-b">الفئة</th>
                <th scope="col" className="py-2 px-4 border-b">الوصف</th>
                <th scope="col" className="py-2 px-4 border-b">المبلغ</th>
                <th scope="col" className="py-2 px-4 border-b">الإجراءات</th>
              </tr>
            </thead>
            <tbody>
              {expenses.length === 0 ? (
                <tr><td colSpan={5} className="text-center py-4 text-gray-600">لا توجد مصاريف للعام الكشفي المحدد.</td></tr>
              ) : (
                expenses.map((record) => (
                  <tr key={record.id} className="hover:bg-gray-50">
                    <td className="py-2 px-4 border-b text-gray-700">{record.date}</td>
                    <td className="py-2 px-4 border-b text-gray-700">{record.category}</td>
                    <td className="py-2 px-4 border-b text-gray-700">{record.description}</td>
                    <td className="py-2 px-4 border-b text-red-700 font-semibold">{record.amount.toFixed(2)} د.ت</td>
                    <td className="py-2 px-4 border-b">
                      {isAdmin && (
                        <div className="flex space-x-reverse space-x-2">
                          <NeumorphicButton variant="secondary" className="text-xs py-1 px-2" onClick={() => openEditModal(record)} type="button">تعديل</NeumorphicButton>
                          <NeumorphicButton variant="danger" className="text-xs py-1 px-2" onClick={() => handleDeleteRecord(record.id)} type="button">حذف</NeumorphicButton>
                        </div>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
        {isAdmin && (
           <React.Fragment>
            <div className="flex justify-end mt-4">
              <NeumorphicButton onClick={() => {
                setEditingRecord({
                  id: '', date: new Date().toISOString().split('T')[0], type: 'expense',
                  category: dynamicConfig.expenseCategories[0], description: '', amount: 0, scoutingYear: filterYear,
                });
                setIsModalOpen(true);
              }} type="button">
                إضافة مصروف
              </NeumorphicButton>
            </div>
           </React.Fragment>
        )}
      </div>
    );
  };

  const renderContent = () => {
    switch (activeTab) {
      case 'subscriptions':
        return renderSubscriptions();
      case 'campsPayments':
        return renderCampsPayments();
      case 'revenues':
        return renderRevenues();
      case 'expenses':
        return renderExpenses();
      case 'reports':
        return <FinancialReports scoutingYear={filterYear} members={members} activities={activities} />;
      default:
        return null;
    }
  };

  return (
    <div className="p-4 rounded-xl"> {/* Removed bg-gradient-to-br from-neumorphic-light to-neumorphic-bg shadow-neumorphic-out as it's now handled by App.tsx main */}
      <div className="flex flex-col md:flex-row items-center justify-between mb-6 space-y-4 md:space-y-0 md:space-x-reverse md:space-x-4">
        <NeumorphicInput
          type="text"
          placeholder="بحث في السجلات المالية..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full md:flex-grow"
        />
        <NeumorphicSelect
          options={scoutingYears.map(year => ({ value: year, label: `العام الكشفي ${year}` }))}
          value={filterYear}
          onChange={(e) => setFilterYear(e.target.value)}
          className="w-full md:w-1/4"
        />
         {(activeTab === 'subscriptions' || activeTab === 'campsPayments') && (
          <NeumorphicSelect
            options={unitOptions}
            value={filterUnit}
            onChange={(e) => setFilterUnit(e.target.value as Unit | '')}
            className="w-full md:w-1/4"
          />
        )}
      </div>

      <div className="flex overflow-x-auto whitespace-nowrap mb-6">
        <NeumorphicButton
          onClick={() => setActiveTab('subscriptions')}
          className={`flex-shrink-0 mx-1 px-4 py-2 ${activeTab === 'subscriptions' ? 'bg-neumorphic-primary text-white shadow-neumorphic-button-in' : 'bg-neumorphic-bg text-gray-700'}`}
          variant={activeTab === 'subscriptions' ? 'primary' : 'secondary'}
          type="button"
        >
          الإنخراطات السنوية
        </NeumorphicButton>
        <NeumorphicButton
          onClick={() => setActiveTab('campsPayments')}
          className={`flex-shrink-0 mx-1 px-4 py-2 ${activeTab === 'campsPayments' ? 'bg-neumorphic-primary text-white shadow-neumorphic-button-in' : 'bg-neumorphic-bg text-gray-700'}`}
          variant={activeTab === 'campsPayments' ? 'primary' : 'secondary'}
          type="button"
        >
          اشتراكات المخيمات
        </NeumorphicButton>
        <NeumorphicButton
          onClick={() => setActiveTab('revenues')}
          className={`flex-shrink-0 mx-1 px-4 py-2 ${activeTab === 'revenues' ? 'bg-neumorphic-primary text-white shadow-neumorphic-button-in' : 'bg-neumorphic-bg text-gray-700'}`}
          variant={activeTab === 'revenues' ? 'primary' : 'secondary'}
          type="button"
        >
          المداخيل
        </NeumorphicButton>
        <NeumorphicButton
          onClick={() => setActiveTab('expenses')}
          className={`flex-shrink-0 mx-1 px-4 py-2 ${activeTab === 'expenses' ? 'bg-neumorphic-primary text-white shadow-neumorphic-button-in' : 'bg-neumorphic-bg text-gray-700'}`}
          variant={activeTab === 'expenses' ? 'primary' : 'secondary'}
          type="button"
        >
          المصاريف
        </NeumorphicButton>
        <NeumorphicButton
          onClick={() => setActiveTab('reports')}
          className={`flex-shrink-0 mx-1 px-4 py-2 ${activeTab === 'reports' ? 'bg-neumorphic-primary text-white shadow-neumorphic-button-in' : 'bg-neumorphic-bg text-gray-700'}`}
          variant={activeTab === 'reports' ? 'primary' : 'secondary'}
          type="button"
        >
          التقارير المالية
        </NeumorphicButton>
      </div>

      <div>
        {renderContent()}
      </div>

      <FinancialForm
        isOpen={isModalOpen}
        onClose={() => { setIsModalOpen(false); setEditingRecord(null); }}
        onSubmit={handleAddOrUpdateRecord}
        initialData={editingRecord}
        scoutingYear={filterYear}
        members={members}
        activities={activities}
      />
    </div>
  );
}
