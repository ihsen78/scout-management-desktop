
import React from 'react';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer,
} from 'recharts';
import { RevenueCategory, ExpenseCategory } from '../../types'; // These are now string types

interface FinancialChartProps {
  revenues: Record<RevenueCategory, number>;
  expenses: Record<ExpenseCategory, number>;
}

export function FinancialChart({ revenues, expenses }: FinancialChartProps) {
  const allCategories = Array.from(new Set([...Object.keys(revenues), ...Object.keys(expenses)]));

  const data = allCategories.map((category) => ({
    name: category,
    المداخيل: revenues[category as RevenueCategory] || 0,
    المصاريف: expenses[category as ExpenseCategory] || 0,
  }));

  return (
    <ResponsiveContainer width="100%" height={400}>
      <BarChart
        data={data}
        margin={{
          top: 20, right: 30, left: 20, bottom: 5,
        }}
        layout="vertical" // Changed to vertical layout
      >
        <CartesianGrid strokeDasharray="3 3" />
        <YAxis dataKey="name" type="category" stroke="#8884d8" reversed={false} /> {/* Adjusted for vertical */}
        <XAxis type="number" stroke="#82ca9d" /> {/* Adjusted for vertical */}
        <Tooltip formatter={(value: number) => `${value.toFixed(2)} د.ت`} />
        <Legend />
        <Bar dataKey="المداخيل" fill="#82ca9d" />
        <Bar dataKey="المصاريف" fill="#ff7300" />
      </BarChart>
    </ResponsiveContainer>
  );
}
