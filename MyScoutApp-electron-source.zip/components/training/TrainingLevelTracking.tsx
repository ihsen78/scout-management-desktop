

import React, { useState, useContext } from 'react';
import { AppContext } from '../../App';
import { Member, Unit } from '../../types';
import { NeumorphicInput } from '../common/NeumorphicInput';
import { NeumorphicSelect } from '../common/NeumorphicSelect';
import { NeumorphicButton } from '../common/NeumorphicButton';
import { exportToPdf } from '../../utils/pdfExport';
import { exportToExcel } from '../../utils/excelExport';

export function TrainingLevelTracking() {
  const context = useContext(AppContext);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterUnit, setFilterUnit] = useState<Unit | ''>('');
  const [filterYear, setFilterYear] = useState<string>(''); // New state for scouting year filter

  if (!context) {
    throw new Error("TrainingLevelTracking must be used within an AppContext.Provider");
  }

  const { members, activities, addNotification, dynamicConfig } = context;

  // Initialize filterYear to the latest scouting year from dynamicConfig
  React.useEffect(() => {
    if (dynamicConfig.scoutingYears.length > 0) {
      setFilterYear(dynamicConfig.scoutingYears[dynamicConfig.scoutingYears.length - 1]);
    }
  }, [dynamicConfig.scoutingYears]);

  const filteredMembers = members.filter((member) => {
    const matchesSearch = member.fullName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          member.trainingLevel.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesUnit = filterUnit === '' || member.unit === filterUnit;
    
    // Filter by scouting year based on member's registrationYear
    let matchesYear = true;
    if (filterYear) {
      const startYear = parseInt(filterYear.split('-')[0]);
      matchesYear = member.registrationYear === startYear;
    }

    return matchesSearch && matchesUnit && matchesYear;
  }).sort((a, b) => a.fullName.localeCompare(b.fullName)); // Sort alphabetically

  const unitOptions = [{ value: '', label: 'جميع الوحدات' }, ...dynamicConfig.units.map((unit) => ({ value: unit, label: unit }))];
  const scoutingYearOptions = dynamicConfig.scoutingYears.map(year => ({ value: year, label: `العام الكشفي ${year}` }));

  const getMemberAchievements = (member: Member) => {
    const memberActivities = activities.filter(activity =>
      activity.unitInvolved.includes(member.unit) && activity.supervisors.includes(member.fullName)
    );

    const achievements = [
      `المستوى التدريبي الحالي: ${member.trainingLevel}`,
      `شارات مكتسبة: ${member.badgesTimeline.join(', ') || 'لا توجد'}`,
      `أنشطة شارك فيها/شرف عليها: ${memberActivities.length} (${memberActivities.map(a => a.title).join(', ')})`,
      `سجل التدريبات: ${member.trainingLog.map(log => log.title).join(', ') || 'لا توجد'}`,
    ];
    return achievements;
  };

  const generateReportContent = () => {
    let content = `
      <div style="font-family: Arial, sans-serif; direction: rtl; text-align: right; padding: 20px;">
        <h1 style="text-align: center; color: #6a82fb;">تقرير المستويات التدريبية - فوج سيدي بوعلي</h1>
        <p style="text-align: center; color: #555;">تاريخ التقرير: ${new Date().toLocaleDateString('ar-TN')}</p>
    `;
    if (searchTerm) content += `<p style="text-align: center;">بحث: "${searchTerm}"</p>`;
    if (filterUnit) content += `<p style="text-align: center;">وحدة مصفاة: ${filterUnit}</p>`;
    if (filterYear) content += `<p style="text-align: center;">العام الكشفي: ${filterYear}</p>`;
    
    if (filteredMembers.length === 0) {
      content += `<p style="text-align: center; color: #888;">لا توجد أعضاء مطابقة لمعايير البحث لإنشاء التقرير.</p>`;
      return content + `</div>`;
    }

    content += `<table style="width:100%; border-collapse: collapse; margin-top: 20px;">
      <thead>
        <tr style="background-color: #f2f2f2;">
          <th scope="col" style="border: 1px solid #ddd; padding: 8px; text-align: right;">الاسم الكامل</th>
          <th scope="col" style="border: 1px solid #ddd; padding: 8px; text-align: right;">الوحدة</th>
          <th scope="col" style="border: 1px solid #ddd; padding: 8px; text-align: right;">المستوى التدريبي</th>
          <th scope="col" style="border: 1px solid #ddd; padding: 8px; text-align: right;">الشارات</th>
          <th scope="col" style="border: 1px solid #ddd; padding: 8px; text-align: right;">التقدم والإنجازات</th>
        </tr>
      </thead>
      <tbody>`;

    filteredMembers.forEach((member) => {
      content += `<tr>
        <td style="border: 1px solid #ddd; padding: 8px; text-align: right;">${member.fullName}</td>
        <td style="border: 1px solid #ddd; padding: 8px; text-align: right;">${member.unit}</td>
        <td style="border: 1px solid #ddd; padding: 8px; text-align: right;">${member.trainingLevel}</td>
        <td style="border: 1px solid #ddd; padding: 8px; text-align: right;">${member.badgesTimeline.join(', ') || 'لا توجد'}</td>
        <td style="border: 1px solid #ddd; padding: 8px; text-align: right;">
          <ul style="margin: 0; padding-right: 20px;">
            ${getMemberAchievements(member).map(a => `<li>${a}</li>`).join('')}
          </ul>
        </td>
      </tr>`;
    });
    content += `</tbody></table></div>`;
    return content;
  };

  const handleExportPdf = () => {
    if (filteredMembers.length === 0) {
      addNotification({ type: 'warning', message: 'لا توجد بيانات لتصديرها إلى PDF.' });
      return;
    }
    const content = generateReportContent();
    exportToPdf(content, `تقرير-المستويات-التدريبية-${filterYear}-الكشافة-التونسية.pdf`);
    addNotification({ type: 'success', message: 'تم تصدير تقرير المستويات التدريبية إلى PDF.' });
  };

  const handleExportExcel = () => {
    if (filteredMembers.length === 0) {
      addNotification({ type: 'warning', message: 'لا توجد بيانات لتصديرها إلى Excel.' });
      return;
    }
    const headers = ['الاسم الكامل', 'الوحدة', 'المستوى التدريبي', 'سنة التسجيل', 'شارات', 'ملاحظات', 'سجل التدريب'];
    const data = filteredMembers.map(member => [
      member.fullName,
      member.unit,
      member.trainingLevel,
      member.registrationYear,
      member.badgesTimeline.join(', '),
      member.notes,
      member.trainingLog.map(log => `(${log.date}) ${log.title} - ${log.description}`).join('; '),
    ]);
    exportToExcel(headers, data, `تقرير-المستويات-التدريبية-${filterYear}-الكشافة-التونسية.xlsx`);
    addNotification({ type: 'success', message: 'تم تصدير تقرير المستويات التدريبية إلى Excel.' });
  };


  return (
    <div className="p-4 rounded-xl"> {/* Removed bg-gradient-to-br from-neumorphic-light to-neumorphic-bg shadow-neumorphic-out as it's now handled by App.tsx main */}
      <div className="flex flex-col md:flex-row items-center justify-between mb-6 space-y-4 md:space-y-0 md:space-x-reverse md:space-x-4">
        <NeumorphicInput
          type="text"
          placeholder="ابحث عن عضو أو مستوى تدريبي..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full md:w-1/3"
        />
        <NeumorphicSelect
          options={unitOptions}
          value={filterUnit}
          onChange={(e) => setFilterUnit(e.target.value as Unit | '')}
          className="w-full md:w-1/3"
        />
        <NeumorphicSelect
          options={scoutingYearOptions}
          value={filterYear}
          onChange={(e) => setFilterYear(e.target.value)}
          className="w-full md:w-1/3"
        />
        <div className="flex space-x-reverse space-x-2 w-full md:w-1/3">
          <NeumorphicButton onClick={handleExportPdf} variant="secondary" className="w-1/2 text-sm" type="button">
            تصدير PDF
          </NeumorphicButton>
          <NeumorphicButton onClick={handleExportExcel} variant="secondary" className="w-1/2 text-sm" type="button">
            تصدير Excel
          </NeumorphicButton>
        </div>
      </div>

      <div className="space-y-6">
        {filteredMembers.length === 0 ? (
          <p className="text-center text-gray-600">لا توجد أعضاء مطابقة لمعايير البحث أو التصفية.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="min-w-full bg-white rounded-lg shadow-md overflow-hidden text-right">
              <thead className="bg-gray-100">
                <tr>
                  <th scope="col" className="py-2 px-4 border-b">الاسم الكامل</th>
                  <th scope="col" className="py-2 px-4 border-b">الوحدة</th>
                  <th scope="col" className="py-2 px-4 border-b">المستوى التدريبي</th>
                  <th scope="col" className="py-2 px-4 border-b">شارات مكتسبة</th>
                  <th scope="col" className="py-2 px-4 border-b">التقدم والإنجازات</th>
                </tr>
              </thead>
              <tbody>
                {filteredMembers.map((member) => (
                  <tr key={member.id} className="hover:bg-gray-50">
                    <td className="py-2 px-4 border-b text-gray-700 font-bold">{member.fullName}</td>
                    <td className="py-2 px-4 border-b text-gray-700">{member.unit}</td>
                    <td className="py-2 px-4 border-b text-gray-700">{member.trainingLevel}</td>
                    <td className="py-2 px-4 border-b text-gray-700">{member.badgesTimeline.join(', ') || 'لا توجد'}</td>
                    <td className="py-2 px-4 border-b text-gray-700">
                      <ul className="list-disc list-inside text-sm space-y-1">
                        {getMemberAchievements(member).map((achievement, index) => (
                          <li key={index}>{achievement}</li>
                        ))}
                      </ul>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}