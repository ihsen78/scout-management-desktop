import React, { useState } from 'react';
import { NeumorphicCard } from './NeumorphicCard';
import { NeumorphicButton } from './NeumorphicButton';

interface CollapsiblePanelProps {
  title: string;
  children?: React.ReactNode;
  initialOpen?: boolean;
  className?: string;
}

export function CollapsiblePanel({ title, children, initialOpen = true, className = '' }: CollapsiblePanelProps) {
  const [isOpen, setIsOpen] = useState(initialOpen);

  return (
    <NeumorphicCard className={`col-span-1 p-0 ${className}`}>
      <div className="flex items-center justify-between p-4 border-b border-gray-200">
        <h2 className="text-xl font-bold text-neumorphic-primary">{title}</h2>
        <NeumorphicButton
          onClick={() => setIsOpen(!isOpen)}
          variant="secondary"
          className="text-sm p-2"
          type="button"
          aria-expanded={isOpen}
          aria-controls={`panel-content-${title.replace(/\s/g, '-')}`}
        >
          {isOpen ? '▲' : '▼'}
        </NeumorphicButton>
      </div>
      {isOpen && (
        <div id={`panel-content-${title.replace(/\s/g, '-')}`} className="p-4 pt-0 mt-4">
          {children}
        </div>
      )}
    </NeumorphicCard>
  );
}