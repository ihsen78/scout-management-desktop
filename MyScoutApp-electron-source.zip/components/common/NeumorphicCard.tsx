import React from 'react';

interface NeumorphicCardProps {
  children?: React.ReactNode;
  className?: string;
}

export function NeumorphicCard({ children, className = '' }: NeumorphicCardProps) {
  return (
    <div
      className={`bg-gradient-to-br from-neumorphic-light to-neumorphic-bg rounded-xl shadow-neumorphic-out p-6 ${className}`}
    >
      {children}
    </div>
  );
}