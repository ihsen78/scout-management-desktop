import React from 'react';

interface CustomNeumorphicButtonProps {
  children: React.ReactNode;
  className?: string;
  variant?: 'primary' | 'secondary' | 'danger' | 'success';
}

export type NeumorphicButtonProps = CustomNeumorphicButtonProps & React.ComponentPropsWithoutRef<'button'>;

export function NeumorphicButton({
  children,
  className = '',
  variant = 'primary',
  ...props // All standard HTML button props will be in 'props'
}: NeumorphicButtonProps) {
  const baseClasses = "rounded-lg shadow-neumorphic-button-out hover:shadow-neumorphic-out active:shadow-neumorphic-button-in font-semibold py-2 px-4 transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2";
  
  let variantClasses = '';
  switch (variant) {
    case 'primary':
      variantClasses = 'bg-neumorphic-primary text-white hover:bg-neumorphic-primary/90 focus:ring-neumorphic-primary';
      break;
    case 'secondary':
      variantClasses = 'bg-neumorphic-secondary text-white hover:bg-neumorphic-secondary/90 focus:ring-neumorphic-secondary';
      break;
    case 'danger':
      variantClasses = 'bg-red-500 text-white hover:bg-red-600 focus:ring-red-500';
      break;
    case 'success':
      variantClasses = 'bg-green-500 text-white hover:bg-green-600 focus:ring-green-500';
      break;
  }

  return (
    <button className={`${baseClasses} ${variantClasses} ${className}`} {...props}>
      {children}
    </button>
  );
}