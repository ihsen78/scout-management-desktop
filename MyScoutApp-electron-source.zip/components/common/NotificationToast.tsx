import React, { useEffect, useState } from 'react';
import { Notification } from '../../types';

interface NotificationToastProps extends Notification {
  key?: React.Key; // Added to satisfy TypeScript when 'key' is passed directly to the component.
  onClose: () => void;
  duration?: number; // Duration in milliseconds before auto-closing
}

export function NotificationToast({ id, message, type, onClose, duration = 5000 }: NotificationToastProps) {
  const [isVisible, setIsVisible] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsVisible(false);
      // Give a little time for the fade-out transition before removing
      setTimeout(onClose, 300);
    }, duration);

    return () => clearTimeout(timer);
  }, [duration, onClose]);

  let bgColor = 'bg-gray-700';
  let icon = '💬';

  switch (type) {
    case 'success':
      bgColor = 'bg-green-500';
      icon = '✅';
      break;
    case 'error':
      bgColor = 'bg-red-500';
      icon = '❌';
      break;
    case 'info':
      bgColor = 'bg-blue-500';
      icon = 'ℹ️';
      break;
    case 'warning':
      bgColor = 'bg-yellow-500';
      icon = '⚠️';
      break;
  }

  return (
    <div
      className={`fixed bottom-4 left-1/2 -translate-x-1/2 p-4 rounded-lg shadow-lg text-white text-center transition-all duration-300 ease-out z-50
      ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'} ${bgColor}`}
      role="alert"
    >
      <div className="flex items-center space-x-reverse space-x-2">
        <span className="text-xl">{icon}</span>
        <span>{message}</span>
        <button onClick={onClose} className="ml-4 text-white hover:text-gray-200 focus:outline-none" aria-label="إغلاق الإشعار">
          &times;
        </button>
      </div>
    </div>
  );
}