import React from 'react';
import { NeumorphicCard } from './NeumorphicCard';
import { NeumorphicButton } from './NeumorphicButton';

interface NeumorphicModalProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  children?: React.ReactNode;
}

export function NeumorphicModal({ isOpen, onClose, title, children }: NeumorphicModalProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-30 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <NeumorphicCard className="relative w-full max-w-lg mx-auto p-6">
        <h2 className="text-2xl font-bold text-neumorphic-primary mb-4 border-b pb-2 border-gray-300">
          {title}
        </h2>
        <div>{children}</div>
        <div className="flex justify-end mt-6">
          <NeumorphicButton onClick={onClose} variant="secondary" type="button">
            إغلاق
          </NeumorphicButton>
        </div>
      </NeumorphicCard>
    </div>
  );
}