

import React, { useState, useContext } from 'react';
import { AppContext } from '../../App';
import { Activity, Unit } from '../../types'; // Unit is now string type
import { NeumorphicButton } from '../common/NeumorphicButton';
import { NeumorphicInput } from '../common/NeumorphicInput';
import { NeumorphicSelect } from '../common/NeumorphicSelect';
import { ActivityForm } from './ActivityForm';
import { generateUniqueId } from '../../utils/idGenerator';
import { exportToPdf } from '../../utils/pdfExport';
import { exportToExcel } from '../../utils/excelExport';

type ActivityCategory = 'completed' | 'upcoming' | 'camps' | 'trips' | 'outings';

export function ActivitiesManagement() {
  const context = useContext(AppContext);
  const [activeTab, setActiveTab] = useState<ActivityCategory>('upcoming');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingActivity, setEditingActivity] = useState<Activity | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterUnit, setFilterUnit] = useState<Unit | ''>('');
  const [filterYear, setFilterYear] = useState<string>(''); // New state for scouting year filter


  if (!context) {
    throw new Error("ActivitiesManagement must be used within an AppContext.Provider");
  }

  const { activities, setActivities, members, addNotification, isAdmin, getUnitIcon, dynamicConfig } = context;

  // Initialize filterYear to the latest scouting year from dynamicConfig
  React.useEffect(() => {
    if (dynamicConfig.scoutingYears.length > 0) {
      setFilterYear(dynamicConfig.scoutingYears[dynamicConfig.scoutingYears.length - 1]);
    }
  }, [dynamicConfig.scoutingYears]);


  const handleAddOrUpdateActivity = (newActivity: Activity) => {
    if (editingActivity) {
      setActivities(activities.map((a) => (a.id === newActivity.id ? newActivity : a)));
      addNotification({ type: 'success', message: 'تم تحديث النشاط بنجاح.' });
    } else {
      setActivities([...activities, { ...newActivity, id: generateUniqueId() }]);
      addNotification({ type: 'success', message: 'تمت إضافة نشاط جديد بنجاح.' });
    }
    setIsModalOpen(false);
    setEditingActivity(null);
  };

  const handleDeleteActivity = (id: string) => {
    if (!isAdmin) {
      addNotification({ type: 'error', message: 'ليس لديك صلاحية لحذف الأنشطة.' });
      return;
    }
    if (window.confirm('هل أنت متأكد من حذف هذا النشاط؟')) {
      setActivities(activities.filter((a) => a.id !== id));
      addNotification({ type: 'success', message: 'تم حذف النشاط بنجاح.' });
    }
  };

  const openEditModal = (activity: Activity) => {
    if (!isAdmin) {
      addNotification({ type: 'error', message: 'ليس لديك صلاحية لتعديل الأنشطة.' });
      return;
    }
    setEditingActivity(activity);
    setIsModalOpen(true);
  };

  const today = new Date().toISOString().split('T')[0]; // YYYY-MM-DD

  const getCategorizedActivities = (category: ActivityCategory) => {
    let filteredActivities = activities.filter(activity =>
      activity.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      activity.supervisors.some(s => s.toLowerCase().includes(searchTerm.toLowerCase())) ||
      activity.notes.toLowerCase().includes(searchTerm.toLowerCase())
    );

    filteredActivities = filteredActivities.filter(activity =>
      filterUnit === '' || activity.unitInvolved.includes(filterUnit as Unit)
    );

    // Filter by scouting year
    if (filterYear) {
      const [startYearStr, endYearStr] = filterYear.split('-');
      const startYear = parseInt(startYearStr);
      const endYear = parseInt(endYearStr); // This is YYYY+1
      
      const yearStartDate = new Date(startYear, 8, 1); // September 1st of the start year
      const yearEndDate = new Date(endYear, 7, 31);   // August 31st of the end year

      filteredActivities = filteredActivities.filter(activity => {
        const activityDate = new Date(activity.date);
        return activityDate >= yearStartDate && activityDate <= yearEndDate;
      });
    }

    switch (category) {
      case 'completed':
        return filteredActivities.filter(a => a.status === 'منفذ' || a.date < today);
      case 'upcoming':
        return filteredActivities.filter(a => a.status === 'مخطط' && a.date >= today);
      case 'camps':
        return filteredActivities.filter(a => a.type === dynamicConfig.activityTypes[0]); // Using first dynamic activity type as 'مخيم'
      case 'trips':
        return filteredActivities.filter(a => a.type === dynamicConfig.activityTypes[1]); // Using second dynamic activity type as 'رحلة'
      case 'outings':
        return filteredActivities.filter(a => a.type === dynamicConfig.activityTypes[2]); // Using third dynamic activity type as 'خرجة'
      default:
        return [];
    }
  };

  const tabs: { category: ActivityCategory; label: string }[] = [
    { category: 'upcoming', label: 'الأنشطة القادمة' },
    { category: 'completed', label: 'الأنشطة المنجزة' },
    { category: 'camps', label: 'المخيمات' },
    { category: 'trips', label: 'الرحلات' },
    { category: 'outings', label: 'الخرجات' },
  ];

  const unitOptions = [{ value: '', label: 'جميع الوحدات' }, ...dynamicConfig.units.map((unit) => ({ value: unit, label: unit }))];
  const scoutingYearOptions = dynamicConfig.scoutingYears.map(year => ({ value: year, label: `العام الكشفي ${year}` }));


  const handleExportPdf = () => {
    const currentActivities = getCategorizedActivities(activeTab);
    if (currentActivities.length === 0) {
      addNotification({ type: 'warning', message: 'لا توجد بيانات لتصديرها إلى PDF في هذا التبويب.' });
      return;
    }

    let htmlContent = `
      <div style="font-family: Arial, sans-serif; direction: rtl; text-align: right; padding: 20px;">
        <h1 style="text-align: center; color: #6a82fb;">تقرير الأنشطة - ${tabs.find(t => t.category === activeTab)?.label} - فوج سيدي بوعلي</h1>
        <p style="text-align: center; color: #555;">تاريخ التقرير: ${new Date().toLocaleDateString('ar-TN')}</p>
        ${filterYear ? `<p style="text-align: center; color: #555;">العام الكشفي: ${filterYear}</p>` : ''}
        <hr style="margin: 20px 0; border: 0; border-top: 1px solid #eee;">
    `;
    
    htmlContent += `<table style="width:100%; border-collapse: collapse; margin-bottom: 20px;">
                      <thead>
                        <tr style="background-color: #f2f2f2;">
                          <th style="padding: 8px; border: 1px solid #ddd; text-align: right;">العنوان</th>
                          <th style="padding: 8px; border: 1px solid #ddd; text-align: right;">النوع</th>
                          <th style="padding: 8px; border: 1px solid #ddd; text-align: right;">التاريخ</th>
                          <th style="padding: 8px; border: 1px solid #ddd; text-align: right;">الوحدات المعنية</th>
                          <th style="padding: 8px; border: 1px solid #ddd; text-align: right;">المشرفون</th>
                          <th style="padding: 8px; border: 1px solid #ddd; text-align: right;">الميزانية المخططة</th>
                          <th style="padding: 8px; border: 1px solid #ddd; text-align: right;">الميزانية الفعلية</th>
                          <th style="padding: 8px; border: 1px solid #ddd; text-align: right;">الحالة</th>
                          <th style="padding: 8px; border: 1px solid #ddd; text-align: right;">الوثائق المرفقة</th>
                          <th style="padding: 8px; border: 1px solid #ddd; text-align: right;">ملاحظات</th>
                        </tr>
                      </thead>
                      <tbody>`;
    currentActivities.forEach(activity => {
      htmlContent += `<tr>
                        <td style="padding: 8px; border: 1px solid #ddd; text-align: right;">${activity.title}</td>
                        <td style="padding: 8px; border: 1px solid #ddd; text-align: right;">${activity.type}</td>
                        <td style="padding: 8px; border: 1px solid #ddd; text-align: right;">${activity.date}</td>
                        <td style="padding: 8px; border: 1px solid #ddd; text-align: right;">${activity.unitInvolved.map(unit => `${unit}`).join(', ')}</td>
                        <td style="padding: 8px; border: 1px solid #ddd; text-align: right;">${activity.supervisors.join(', ')}</td>
                        <td style="padding: 8px; border: 1px solid #ddd; text-align: right;">${activity.plannedBudget.toFixed(2)} د.ت</td>
                        <td style="padding: 8px; border: 1px solid #ddd; text-align: right;">${activity.actualBudget.toFixed(2)} د.ت</td>
                        <td style="padding: 8px; border: 1px solid #ddd; text-align: right;">${activity.status}</td>
                        <td style="padding: 8px; border: 1px solid #ddd; text-align: right;">${activity.attachedDocuments.join(', ') || 'لا توجد'}</td>
                        <td style="padding: 8px; border: 1px solid #ddd; text-align: right;">${activity.notes || 'لا توجد'}</td>
                      </tr>`;
    });
    htmlContent += `</tbody></table></div>`;
    exportToPdf(htmlContent, `تقرير-الأنشطة-${activeTab}-${filterYear}-الكشافة-التونسية.pdf`);
    addNotification({ type: 'success', message: `تم تصدير تقرير الأنشطة لـ ${tabs.find(t => t.category === activeTab)?.label} إلى PDF.` });
  };

  const handleExportExcel = () => {
    const currentActivities = getCategorizedActivities(activeTab);
    if (currentActivities.length === 0) {
      addNotification({ type: 'warning', message: 'لا توجد بيانات لتصديرها إلى Excel في هذا التبويب.' });
      return;
    }

    const headers = ['العنوان', 'النوع', 'التاريخ', 'الوحدات المعنية', 'المشرفون', 'الميزانية المخططة', 'الميزانية الفعلية', 'الحالة', 'الوثائق المرفقة', 'ملاحظات'];
    const data = currentActivities.map(activity => [
      activity.title,
      activity.type,
      activity.date,
      activity.unitInvolved.map(unit => `${unit}`).join(', '),
      activity.supervisors.join(', '),
      activity.plannedBudget.toFixed(2),
      activity.actualBudget.toFixed(2),
      activity.status,
      activity.attachedDocuments.join(', '),
      activity.notes,
    ]);
    exportToExcel(headers, data, `تقرير-الأنشطة-${activeTab}-${filterYear}-الكشافة-التونسية.xlsx`);
    addNotification({ type: 'success', message: `تم تصدير تقرير الأنشطة لـ ${tabs.find(t => t.category === activeTab)?.label} إلى Excel.` });
  };

  return (
    <div className="p-4 rounded-xl"> {/* Removed bg-gradient-to-br from-neumorphic-light to-neumorphic-bg shadow-neumorphic-out as it's now handled by App.tsx main */}
      <div className="flex flex-col md:flex-row items-center justify-between mb-6 space-y-4 md:space-y-0 md:space-x-reverse md:space-x-4">
        <NeumorphicInput
          type="text"
          placeholder="ابحث عن نشاط..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full md:flex-grow"
        />
        <NeumorphicSelect
          options={unitOptions}
          value={filterUnit}
          onChange={(e) => setFilterUnit(e.target.value as Unit | '')}
          className="w-full md:w-1/4"
        />
        <NeumorphicSelect
          options={scoutingYearOptions}
          value={filterYear}
          onChange={(e) => setFilterYear(e.target.value)}
          className="w-full md:w-1/4"
        />
        <div className="flex space-x-reverse space-x-2 w-full md:w-auto">
          {isAdmin && (
             <React.Fragment>
              <NeumorphicButton onClick={() => { setEditingActivity(null); setIsModalOpen(true); }} className="w-full md:w-auto" type="button">
                إضافة نشاط
              </NeumorphicButton>
             </React.Fragment>
          )}
          <NeumorphicButton onClick={handleExportPdf} variant="secondary" className="w-1/2 md:w-auto text-sm" type="button">
            تصدير PDF
          </NeumorphicButton>
          <NeumorphicButton onClick={handleExportExcel} variant="secondary" className="w-1/2 md:w-auto text-sm" type="button">
            تصدير Excel
          </NeumorphicButton>
        </div>
      </div>

      <div className="flex overflow-x-auto whitespace-nowrap mb-6">
        {tabs.map((tab) => (
          <NeumorphicButton
            key={tab.category}
            onClick={() => setActiveTab(tab.category)}
            className={`flex-shrink-0 mx-1 px-4 py-2 ${activeTab === tab.category ? 'bg-neumorphic-primary text-white shadow-neumorphic-button-in' : 'bg-neumorphic-bg text-gray-700'}`}
            variant={activeTab === tab.category ? 'primary' : 'secondary'}
            type="button"
          >
            {tab.label}
          </NeumorphicButton>
        ))}
      </div>

      <div className="space-y-4">
        {getCategorizedActivities(activeTab).length === 0 ? (
          <p className="text-center text-gray-600">لا توجد أنشطة في هذا التصنيف أو مطابقة لمعايير البحث.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="min-w-full bg-white rounded-lg shadow-md overflow-hidden text-right">
              <thead className="bg-gray-100">
                <tr>
                  <th scope="col" className="py-2 px-4 border-b">العنوان</th>
                  <th scope="col" className="py-2 px-4 border-b">النوع</th>
                  <th scope="col" className="py-2 px-4 border-b">التاريخ</th>
                  <th scope="col" className="py-2 px-4 border-b">الوحدات المعنية</th>
                  <th scope="col" className="py-2 px-4 border-b">المشرفون</th>
                  <th scope="col" className="py-2 px-4 border-b">الميزانية المخططة</th>
                  <th scope="col" className="py-2 px-4 border-b">الميزانية الفعلية</th>
                  <th scope="col" className="py-2 px-4 border-b">الحالة</th>
                  <th scope="col" className="py-2 px-4 border-b">الوثائق المرفقة</th>
                  <th scope="col" className="py-2 px-4 border-b">ملاحظات</th>
                  {isAdmin && <th scope="col" className="py-2 px-4 border-b">إجراءات</th>}
                </tr>
              </thead>
              <tbody>
                {getCategorizedActivities(activeTab).map((activity) => (
                  <tr key={activity.id} className="hover:bg-gray-50">
                    <td className="py-2 px-4 border-b text-gray-700 font-bold">{activity.title}</td>
                    <td className="py-2 px-4 border-b text-gray-700">{activity.type}</td>
                    <td className="py-2 px-4 border-b text-gray-700">{activity.date}</td>
                    <td className="py-2 px-4 border-b text-gray-700">
                      {activity.unitInvolved.map((unit, index) => (
                        <React.Fragment key={unit}>
                          {getUnitIcon(unit)} {unit}{index < activity.unitInvolved.length - 1 ? ', ' : ''}
                        </React.Fragment>
                      ))}
                    </td>
                    <td className="py-2 px-4 border-b text-gray-700">{activity.supervisors.join(', ')}</td>
                    <td className="py-2 px-4 border-b text-gray-700">{activity.plannedBudget.toFixed(2)} د.ت</td>
                    <td className="py-2 px-4 border-b text-gray-700">{activity.actualBudget.toFixed(2)} د.ت</td>
                    <td className="py-2 px-4 border-b text-gray-700">{activity.status}</td>
                    <td className="py-2 px-4 border-b text-gray-700">{activity.attachedDocuments.join(', ') || 'لا توجد'}</td>
                    <td className="py-2 px-4 border-b text-gray-700 line-clamp-2">{activity.notes || 'لا توجد ملاحظات.'}</td>
                    {isAdmin && (
                      <td className="py-2 px-4 border-b">
                        <div className="flex justify-end space-x-reverse space-x-2">
                          <NeumorphicButton variant="secondary" onClick={() => openEditModal(activity)} className="text-xs py-1 px-2" type="button">
                            تعديل
                          </NeumorphicButton>
                          <NeumorphicButton variant="danger" onClick={() => handleDeleteActivity(activity.id)} className="text-xs py-1 px-2" type="button">
                            حذف
                          </NeumorphicButton>
                        </div>
                      </td>
                    )}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      <ActivityForm
        isOpen={isModalOpen}
        onClose={() => { setIsModalOpen(false); setEditingActivity(null); }}
        onSubmit={handleAddOrUpdateActivity}
        initialData={editingActivity}
        members={members}
      />
    </div>
  );
}