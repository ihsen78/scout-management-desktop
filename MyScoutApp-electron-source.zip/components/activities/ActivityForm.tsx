
import React, { useState, useEffect, useContext } from 'react';
import { Activity, ActivityType, Unit, Member } from '../../types';
import { NeumorphicModal } from '../common/NeumorphicModal';
import { NeumorphicInput } from '../common/NeumorphicInput';
import { NeumorphicSelect } from '../common/NeumorphicSelect';
import { NeumorphicButton } from '../common/NeumorphicButton';
import { AppContext } from '../../App';

interface ActivityFormProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (activity: Activity) => void;
  initialData?: Activity | null;
  members: Member[]; // To select supervisors
}

export function ActivityForm({ isOpen, onClose, onSubmit, initialData, members }: ActivityFormProps) {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error("ActivityForm must be used within an AppContext.Provider");
  }
  const { dynamicConfig } = context;

  const [formData, setFormData] = useState<Omit<Activity, 'id'>>({
    title: '',
    type: dynamicConfig.activityTypes[0] || '', // Default to first available activity type
    date: '',
    unitInvolved: [],
    supervisors: [],
    plannedBudget: 0,
    actualBudget: 0,
    status: 'مخطط',
    notes: '',
    attachedDocuments: [],
  });

  useEffect(() => {
    if (initialData) {
      setFormData(initialData);
    } else {
      setFormData({
        title: '',
        type: dynamicConfig.activityTypes[0] || '', // Default to first available activity type
        date: '',
        unitInvolved: [],
        supervisors: [],
        plannedBudget: 0,
        actualBudget: 0,
        status: 'مخطط',
        notes: '',
        attachedDocuments: [],
      });
    }
  }, [initialData, isOpen, dynamicConfig.activityTypes]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value, type } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: type === 'number' ? parseFloat(value) : value,
    }));
  };

  const handleMultiSelectChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const { name, options } = e.target;
    // Fix: Explicitly type `option` as `HTMLOptionElement`
    const selectedValues = Array.from(options)
      .filter((option: HTMLOptionElement) => option.selected)
      .map((option: HTMLOptionElement) => option.value);
    setFormData((prev) => ({
      ...prev,
      [name]: selectedValues,
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit({ ...formData, id: initialData?.id || '' });
  };

  const activityTypeOptions = dynamicConfig.activityTypes.map((type) => ({ value: type, label: type }));
  const unitOptions = dynamicConfig.units.map((unit) => ({ value: unit, label: unit }));
  const statusOptions = [
    { value: 'مخطط', label: 'مخطط' },
    { value: 'منفذ', label: 'منفذ' },
    { value: 'ملغى', label: 'ملغى' },
  ];
  const supervisorOptions = members.map((member) => ({ value: member.fullName, label: member.fullName }));

  return (
    <NeumorphicModal isOpen={isOpen} onClose={onClose} title={initialData ? 'تعديل النشاط' : 'إضافة نشاط جديد'}>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-gray-700 text-sm font-bold mb-2">العنوان:</label>
          <NeumorphicInput
            type="text"
            name="title"
            value={formData.title}
            onChange={handleChange}
            required
            className="w-full"
          />
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-gray-700 text-sm font-bold mb-2">النوع:</label>
            <NeumorphicSelect
              name="type"
              options={activityTypeOptions}
              value={formData.type}
              onChange={handleChange}
              required
              className="w-full"
            />
          </div>
          <div>
            <label className="block text-gray-700 text-sm font-bold mb-2">التاريخ:</label>
            <NeumorphicInput
              type="date"
              name="date"
              value={formData.date}
              onChange={handleChange}
              required
              className="w-full"
            />
          </div>
        </div>
        <div>
          <label className="block text-gray-700 text-sm font-bold mb-2">الوحدات المعنية:</label>
          <select
            name="unitInvolved"
            multiple
            value={formData.unitInvolved}
            onChange={handleMultiSelectChange}
            required
            className="bg-neumorphic-bg rounded-lg shadow-neumorphic-in border-transparent focus:border-neumorphic-primary focus:outline-none focus:ring-2 focus:ring-neumorphic-primary transition-all duration-200 px-3 py-2 text-gray-700 w-full h-24"
          >
            {unitOptions.map((option) => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </select>
        </div>
        <div>
          <label className="block text-gray-700 text-sm font-bold mb-2">المشرفون:</label>
          <select
            name="supervisors"
            multiple
            value={formData.supervisors}
            onChange={handleMultiSelectChange}
            className="bg-neumorphic-bg rounded-lg shadow-neumorphic-in border-transparent focus:border-neumorphic-primary focus:outline-none focus:ring-2 focus:ring-neumorphic-primary transition-all duration-200 px-3 py-2 text-gray-700 w-full h-24"
          >
            {supervisorOptions.map((option) => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </select>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-gray-700 text-sm font-bold mb-2">الميزانية المخططة:</label>
            <NeumorphicInput
              type="number"
              name="plannedBudget"
              value={formData.plannedBudget}
              onChange={handleChange}
              className="w-full"
            />
          </div>
          <div>
            <label className="block text-gray-700 text-sm font-bold mb-2">الميزانية الفعلية:</label>
            <NeumorphicInput
              type="number"
              name="actualBudget"
              value={formData.actualBudget}
              onChange={handleChange}
              className="w-full"
            />
          </div>
        </div>
        <div>
          <label className="block text-gray-700 text-sm font-bold mb-2">الحالة:</label>
          <NeumorphicSelect
            name="status"
            options={statusOptions}
            value={formData.status}
            onChange={handleChange}
            className="w-full"
          />
        </div>
        <div>
          <label className="block text-gray-700 text-sm font-bold mb-2">ملاحظات:</label>
          <textarea
            name="notes"
            value={formData.notes}
            onChange={handleChange}
            rows={3}
            className="bg-neumorphic-bg rounded-lg shadow-neumorphic-in border-transparent focus:border-neumorphic-primary focus:outline-none focus:ring-2 focus:ring-neumorphic-primary transition-all duration-200 px-3 py-2 text-gray-700 placeholder-gray-500 w-full"
          ></textarea>
        </div>
        <div>
          <label className="block text-gray-700 text-sm font-bold mb-2">الوثائق المرفقة (مفصولة بفاصلة):</label>
          <NeumorphicInput
            type="text"
            name="attachedDocuments"
            value={formData.attachedDocuments.join(', ')}
            onChange={(e) => setFormData((prev) => ({ ...prev, attachedDocuments: e.target.value.split(',').map(s => s.trim()).filter(Boolean) }))}
            className="w-full"
          />
        </div>
        <div className="flex justify-end space-x-reverse space-x-2 mt-6">
          <NeumorphicButton type="submit" variant="primary">
            {initialData ? 'تعديل' : 'إضافة'}
          </NeumorphicButton>
          <NeumorphicButton type="button" variant="secondary" onClick={onClose}>
            إلغاء
          </NeumorphicButton>
        </div>
      </form>
    </NeumorphicModal>
  );
}
