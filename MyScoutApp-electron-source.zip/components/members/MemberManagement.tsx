

import React, { useState, useContext } from 'react';
import { AppContext } from '../../App';
import { Member, Unit, SubUnit } from '../../types';
import { NeumorphicButton } from '../common/NeumorphicButton';
import { NeumorphicInput } from '../common/NeumorphicInput';
import { NeumorphicSelect } from '../common/NeumorphicSelect';
import { MemberForm } from './MemberForm';
import { generateUniqueId } from '../../utils/idGenerator';
import { exportToPdf } from '../../utils/pdfExport';
import { exportToExcel } from '../../utils/excelExport';

export function MemberManagement() {
  const context = useContext(AppContext);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingMember, setEditingMember] = useState<Member | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterUnit, setFilterUnit] = useState<Unit | ''>('');
  const [filterSubUnit, setFilterSubUnit] = useState<SubUnit | ''>('');
  const [filterYear, setFilterYear] = useState<string>(''); // New state for scouting year filter

  if (!context) {
    throw new Error("MemberManagement must be used within an AppContext.Provider");
  }

  const { members, setMembers, addNotification, isAdmin, getUnitIcon, dynamicConfig } = context;

  // Initialize filterYear to the latest scouting year from dynamicConfig
  React.useEffect(() => {
    if (dynamicConfig.scoutingYears.length > 0) {
      setFilterYear(dynamicConfig.scoutingYears[dynamicConfig.scoutingYears.length - 1]);
    }
  }, [dynamicConfig.scoutingYears]);

  const handleAddOrUpdateMember = (newMember: Member) => {
    if (editingMember) {
      setMembers(members.map((m) => (m.id === newMember.id ? newMember : m)));
      addNotification({ type: 'success', message: 'تم تحديث بيانات العضو بنجاح.' });
    } else {
      setMembers([...members, { ...newMember, id: generateUniqueId() }]);
      addNotification({ type: 'success', message: 'تمت إضافة عضو جديد بنجاح.' });
    }
    setIsModalOpen(false);
    setEditingMember(null);
  };

  const handleDeleteMember = (id: string) => {
    if (!isAdmin) {
      addNotification({ type: 'error', message: 'ليس لديك صلاحية لحذف الأعضاء.' });
      return;
    }
    if (window.confirm('هل أنت متأكد من حذف هذا العضو؟')) {
      setMembers(members.filter((m) => m.id !== id));
      addNotification({ type: 'success', message: 'تم حذف العضو بنجاح.' });
    }
  };

  const openEditModal = (member: Member) => {
    if (!isAdmin) {
      addNotification({ type: 'error', message: 'ليس لديك صلاحية لتعديل الأعضاء.' });
      return;
    }
    setEditingMember(member);
    setIsModalOpen(true);
  };

  const getSubUnitOptionsForFilter = (unit: Unit | '') => {
    if (!unit) return [];
    return dynamicConfig.subUnits[unit]?.map(s => ({ value: s, label: s })) || [];
  };

  const filteredMembers = members.filter((member) => {
    const matchesSearch = member.fullName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          member.trainingLevel.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          member.contactInfo.includes(searchTerm);
    const matchesUnit = filterUnit === '' || member.unit === filterUnit;
    const matchesSubUnit = filterSubUnit === '' || member.subUnit === filterSubUnit;
    
    // Filter by scouting year based on member's registrationYear
    let matchesYear = true;
    if (filterYear) {
      const startYear = parseInt(filterYear.split('-')[0]);
      matchesYear = member.registrationYear === startYear;
    }

    return matchesSearch && matchesUnit && matchesSubUnit && matchesYear;
  }).sort((a, b) => a.fullName.localeCompare(b.fullName)); // Sort alphabetically

  // Removed groupedMembers for on-screen display to simplify table rendering as requested,
  // but kept logic for PDF export which uses grouping.

  const unitOptions = [{ value: '', label: 'جميع الوحدات' }, ...dynamicConfig.units.map((unit) => ({ value: unit, label: unit }))];
  const subUnitOptions = [{ value: '', label: 'جميع الفرق' }, ...getSubUnitOptionsForFilter(filterUnit)];
  const scoutingYearOptions = dynamicConfig.scoutingYears.map(year => ({ value: year, label: `العام الكشفي ${year}` }));


  const generateMemberReportHtml = () => {
    // This will still use the grouped logic for a more organized PDF report
    const groupedForPdf = filteredMembers.reduce((acc, member) => {
      const unitName = member.unit;
      if (!acc[unitName]) {
        acc[unitName] = {};
      }
      const subUnitName = member.subUnit || 'غير محدد';
      if (!acc[unitName][subUnitName]) {
        acc[unitName][subUnitName] = [];
      }
      acc[unitName][subUnitName].push(member);
      return acc;
    }, {} as Record<string, Record<string, Member[]>>);

    let html = `
      <div style="font-family: Arial, sans-serif; direction: rtl; text-align: right; padding: 20px;">
        <h1 style="text-align: center; color: #6a82fb;">تقرير الأعضاء - فوج سيدي بوعلي</h1>
        <p style="text-align: center; color: #555;">تاريخ التقرير: ${new Date().toLocaleDateString('ar-TN')}</p>
        ${filterYear ? `<p style="text-align: center; color: #555;">العام الكشفي: ${filterYear}</p>` : ''}
        <hr style="margin: 20px 0; border: 0; border-top: 1px solid #eee;">
    `;
  
    if (Object.keys(groupedForPdf).length === 0) {
      html += `<p style="text-align: center;">لا توجد أعضاء مطابقة لمعايير البحث لإنشاء التقرير.</p>`;
      return html + `</div>`;
    }
  
    Object.entries(groupedForPdf).forEach(([unit, subUnits]) => {
      html += `<h2 style="color: #6a82fb; margin-top: 20px;">الوحدة: ${getUnitIcon(unit as Unit)} ${unit}</h2>`;
      Object.entries(subUnits).forEach(([subUnit, membersInSubUnit]) => {
        html += `<h3 style="color: #8b9dc3; margin-top: 15px;">الفرقة: ${subUnit} (${membersInSubUnit.length} أعضاء)</h3>`;
        html += `<table style="width:100%; border-collapse: collapse; margin-bottom: 20px;">
                  <thead>
                    <tr style="background-color: #f2f2f2;">
                      <th scope="col" style="padding: 8px; border: 1px solid #ddd; text-align: right;">الاسم الكامل</th>
                      <th scope="col" style="padding: 8px; border: 1px solid #ddd; text-align: right;">تاريخ الميلاد</th>
                      <th scope="col" style="padding: 8px; border: 1px solid #ddd; text-align: right;">الوحدة</th>
                      <th scope="col" style="padding: 8px; border: 1px solid #ddd; text-align: right;">الفرقة</th>
                      <th scope="col" style="padding: 8px; border: 1px solid #ddd; text-align: right;">المستوى التدريبي</th>
                      <th scope="col" style="padding: 8px; border: 1px solid #ddd; text-align: right;">سنة التسجيل</th>
                      <th scope="col" style="padding: 8px; border: 1px solid #ddd; text-align: right;">الاتصال</th>
                      <th scope="col" style="padding: 8px; border: 1px solid #ddd; text-align: right;">شارات</th>
                      <th scope="col" style="padding: 8px; border: 1px solid #ddd; text-align: right;">سجل التدريب</th>
                      <th scope="col" style="padding: 8px; border: 1px solid #ddd; text-align: right;">ملاحظات</th>
                    </tr>
                  </thead>
                  <tbody>`;
        membersInSubUnit.forEach(member => {
          html += `<tr>
                    <td style="padding: 8px; border: 1px solid #ddd; text-align: right;">${member.fullName}</td>
                    <td style="padding: 8px; border: 1px solid #ddd; text-align: right;">${member.dateOfBirth}</td>
                    <td style="padding: 8px; border: 1px solid #ddd; text-align: right;">${member.unit}</td>
                    <td style="padding: 8px; border: 1px solid #ddd; text-align: right;">${member.subUnit}</td>
                    <td style="padding: 8px; border: 1px solid #ddd; text-align: right;">${member.trainingLevel}</td>
                    <td style="padding: 8px; border: 1px solid #ddd; text-align: right;">${member.registrationYear}</td>
                    <td style="padding: 8px; border: 1px solid #ddd; text-align: right;">${member.contactInfo}</td>
                    <td style="padding: 8px; border: 1px solid #ddd; text-align: right;">${member.badgesTimeline.join(', ') || 'لا توجد'}</td>
                    <td style="padding: 8px; border: 1px solid #ddd; text-align: right;">
                      ${member.trainingLog.map(log => `(${log.date}) ${log.title} ${log.certificateUrl ? `[${log.certificateUrl}]` : ''}`).join('<br/>') || 'لا توجد'}
                    </td>
                    <td style="padding: 8px; border: 1px solid #ddd; text-align: right;">${member.notes}</td>
                  </tr>`;
        });
        html += `</tbody></table>`;
      });
    });
  
    html += `</div>`;
    return html;
  };

  const handleExportPdf = () => {
    if (filteredMembers.length === 0) {
      addNotification({ type: 'warning', message: 'لا توجد بيانات لتصديرها إلى PDF.' });
      return;
    }
    const content = generateMemberReportHtml();
    exportToPdf(content, `تقرير-الأعضاء-${filterYear}-الكشافة-التونسية.pdf`);
    addNotification({ type: 'success', message: 'تم تصدير تقرير الأعضاء إلى PDF.' });
  };

  const handleExportExcel = () => {
    if (filteredMembers.length === 0) {
      addNotification({ type: 'warning', message: 'لا توجد بيانات لتصديرها إلى Excel.' });
      return;
    }
    const headers = ['الاسم الكامل', 'تاريخ الميلاد', 'الوحدة', 'الفرقة', 'المستوى التدريبي', 'سنة التسجيل', 'الاتصال', 'ملاحظات', 'شارات', 'سجل التدريب'];
    const data = filteredMembers.map(member => [
      member.fullName,
      member.dateOfBirth,
      member.unit,
      member.subUnit,
      member.trainingLevel,
      member.registrationYear,
      member.contactInfo,
      member.notes,
      member.badgesTimeline.join(', '),
      member.trainingLog.map(log => `(${log.date}) ${log.title} - ${log.description}`).join('; '), // Concatenate training log entries
    ]);
    exportToExcel(headers, data, `تقرير-الأعضاء-${filterYear}-الكشافة-التونسية.xlsx`);
    addNotification({ type: 'success', message: 'تم تصدير تقرير الأعضاء إلى Excel.' });
  };


  return (
    <div className="p-4 rounded-xl"> {/* Removed bg-gradient-to-br from-neumorphic-light to-neumorphic-bg shadow-neumorphic-out as it's now handled by App.tsx main */}
      <div className="flex flex-col md:flex-row items-center justify-between mb-6 space-y-4 md:space-y-0 md:space-x-reverse md:space-x-4">
        <NeumorphicInput
          type="text"
          placeholder="ابحث عن عضو (الاسم، المستوى، الاتصال...)"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full md:w-1/3"
        />
        <div className="flex flex-col md:flex-row space-y-4 md:space-y-0 md:space-x-reverse md:space-x-4 w-full md:w-2/3">
          <NeumorphicSelect
            options={unitOptions}
            value={filterUnit}
            onChange={(e) => {
              setFilterUnit(e.target.value as Unit | '');
              setFilterSubUnit(''); // Reset sub-unit filter when unit changes
            }}
            className="w-full md:w-1/2"
          />
          <NeumorphicSelect
            options={subUnitOptions}
            value={filterSubUnit}
            onChange={(e) => setFilterSubUnit(e.target.value as SubUnit | '')}
            disabled={filterUnit === '' || subUnitOptions.length <= 1}
            className="w-full md:w-1/2"
          />
        </div>
        <NeumorphicSelect
          options={scoutingYearOptions}
          value={filterYear}
          onChange={(e) => setFilterYear(e.target.value)}
          className="w-full md:w-1/3"
        />
        <div className="flex space-x-reverse space-x-2 w-full md:w-auto">
          {isAdmin && (
            <React.Fragment>
              <NeumorphicButton onClick={() => { setEditingMember(null); setIsModalOpen(true); }} className="w-full md:w-auto" type="button">
                إضافة عضو جديد
              </NeumorphicButton>
            </React.Fragment>
          )}
          <NeumorphicButton onClick={handleExportPdf} variant="secondary" className="w-1/2 md:w-auto text-sm" type="button">
            تصدير PDF
          </NeumorphicButton>
          <NeumorphicButton onClick={handleExportExcel} variant="secondary" className="w-1/2 md:w-auto text-sm" type="button">
            تصدير Excel
          </NeumorphicButton>
        </div>
      </div>

      <div className="space-y-6">
        {filteredMembers.length === 0 ? (
          <p className="text-center text-gray-600">لا توجد أعضاء مطابقة لمعايير البحث.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="min-w-full bg-white rounded-lg shadow-md overflow-hidden text-right">
              <thead className="bg-gray-100">
                <tr>
                  <th scope="col" className="py-2 px-4 border-b">الاسم الكامل</th>
                  <th scope="col" className="py-2 px-4 border-b">الوحدة</th>
                  <th scope="col" className="py-2 px-4 border-b">الفرقة</th>
                  <th scope="col" className="py-2 px-4 border-b">المستوى التدريبي</th>
                  <th scope="col" className="py-2 px-4 border-b">سنة التسجيل</th>
                  <th scope="col" className="py-2 px-4 border-b">الاتصال</th>
                  <th scope="col" className="py-2 px-4 border-b">شارات</th>
                  <th scope="col" className="py-2 px-4 border-b">سجل التدريب</th>
                  <th scope="col" className="py-2 px-4 border-b">ملاحظات</th>
                  {isAdmin && <th scope="col" className="py-2 px-4 border-b">إجراءات</th>}
                </tr>
              </thead>
              <tbody>
                {filteredMembers.map((member) => (
                  <tr key={member.id} className="hover:bg-gray-50">
                    <td className="py-2 px-4 border-b text-gray-700">
                      <div className="flex items-center">
                        {member.profilePicture && (
                          <img src={member.profilePicture} alt={`${member.fullName} profile`} className="w-8 h-8 rounded-full object-cover ml-2 shadow-neumorphic-in" />
                        )}
                        <span className="font-bold">{member.fullName}</span>
                      </div>
                    </td>
                    <td className="py-2 px-4 border-b text-gray-700">{getUnitIcon(member.unit)} {member.unit}</td>
                    <td className="py-2 px-4 border-b text-gray-700">{member.subUnit}</td>
                    <td className="py-2 px-4 border-b text-gray-700">{member.trainingLevel}</td>
                    <td className="py-2 px-4 border-b text-gray-700">{member.registrationYear}</td>
                    <td className="py-2 px-4 border-b text-gray-700">{member.contactInfo}</td>
                    <td className="py-2 px-4 border-b text-gray-700">{member.badgesTimeline.join(', ') || 'لا توجد'}</td>
                    <td className="py-2 px-4 border-b text-gray-700">
                      <ul className="list-disc list-inside text-sm">
                        {member.trainingLog.map((log) => (
                          <li key={log.id}>
                            <strong>{log.title}</strong> ({log.date})
                            {log.certificateUrl && (
                              <a href={log.certificateUrl} target="_blank" rel="noopener noreferrer" className="text-blue-500 hover:underline ml-1">
                                (شهادة)
                              </a>
                            )}
                          </li>
                        ))}
                      </ul>
                      {member.trainingLog.length === 0 && 'لا توجد'}
                    </td>
                    <td className="py-2 px-4 border-b text-gray-700 line-clamp-2">{member.notes}</td>
                    {isAdmin && (
                      <td className="py-2 px-4 border-b">
                        <div className="flex justify-end mt-0 space-x-reverse space-x-2">
                          <NeumorphicButton variant="secondary" onClick={() => openEditModal(member)} className="text-xs py-1 px-2" type="button">
                            تعديل
                          </NeumorphicButton>
                          <NeumorphicButton variant="danger" onClick={() => handleDeleteMember(member.id)} className="text-xs py-1 px-2" type="button">
                            حذف
                          </NeumorphicButton>
                        </div>
                      </td>
                    )}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      <MemberForm
        isOpen={isModalOpen}
        onClose={() => { setIsModalOpen(false); setEditingMember(null); }}
        onSubmit={handleAddOrUpdateMember}
        initialData={editingMember}
      />
    </div>
  );
}