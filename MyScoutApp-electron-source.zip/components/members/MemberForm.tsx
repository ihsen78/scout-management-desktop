
import React, { useState, useEffect, useContext } from 'react';
import { Member, Unit, SubUnit, TrainingLogEntry } from '../../types';
import { NeumorphicModal } from '../common/NeumorphicModal';
import { NeumorphicInput } from '../common/NeumorphicInput';
import { NeumorphicSelect } from '../common/NeumorphicSelect';
import { NeumorphicButton } from '../common/NeumorphicButton';
import { generateUniqueId } from '../../utils/idGenerator';
import { AppContext } from '../../App';

interface MemberFormProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (member: Member) => void;
  initialData?: Member | null;
}

export function MemberForm({ isOpen, onClose, onSubmit, initialData }: MemberFormProps) {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error("MemberForm must be used within an AppContext.Provider");
  }
  const { dynamicConfig } = context;

  const [formData, setFormData] = useState<Omit<Member, 'id'>>({
    fullName: '',
    dateOfBirth: '',
    unit: dynamicConfig.units[0] || '', // Default to first available unit
    subUnit: dynamicConfig.subUnits[dynamicConfig.units[0]]?.[0] || 'غير محدد', // Default to first sub-unit of the first unit
    trainingLevel: '',
    registrationYear: new Date().getFullYear(),
    contactInfo: '',
    notes: '',
    badgesTimeline: [],
    profilePicture: undefined,
    trainingLog: [], // Initialize trainingLog
  });

  const [currentTrainingEntry, setCurrentTrainingEntry] = useState<Omit<TrainingLogEntry, 'id'>>({
    title: '',
    date: '',
    description: '',
    certificateUrl: '',
  });
  const [editingTrainingId, setEditingTrainingId] = useState<string | null>(null);

  useEffect(() => {
    if (initialData) {
      setFormData(initialData);
    } else {
      setFormData({
        fullName: '',
        dateOfBirth: '',
        unit: dynamicConfig.units[0] || '',
        subUnit: dynamicConfig.subUnits[dynamicConfig.units[0]]?.[0] || 'غير محدد',
        trainingLevel: '',
        registrationYear: new Date().getFullYear(),
        contactInfo: '',
        notes: '',
        badgesTimeline: [],
        profilePicture: undefined,
        trainingLog: [],
      });
    }
    // Reset training log input fields when modal opens/closes or initialData changes
    setCurrentTrainingEntry({ title: '', date: '', description: '', certificateUrl: '' });
    setEditingTrainingId(null);
  }, [initialData, isOpen, dynamicConfig.units, dynamicConfig.subUnits]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: name === 'registrationYear' ? parseInt(value) : value,
    }));
  };

  const handleUnitChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const newUnit = e.target.value as Unit;
    setFormData((prev) => ({
      ...prev,
      unit: newUnit,
      subUnit: dynamicConfig.subUnits[newUnit]?.[0] || 'غير محدد', // Set first sub-unit of new unit
    }));
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      const reader = new FileReader();
      reader.onloadend = () => {
        setFormData((prev) => ({
          ...prev,
          profilePicture: reader.result as string, // Store base64 string
        }));
      };
      reader.readAsDataURL(file);
    } else {
      setFormData((prev) => ({
        ...prev,
        profilePicture: undefined, // Clear if no file selected
      }));
    }
  };

  const handleClearPicture = () => {
    setFormData((prev) => ({
      ...prev,
      profilePicture: undefined,
    }));
    // Optionally reset the file input visually
    const fileInput = document.getElementById('profilePictureInput') as HTMLInputElement;
    if (fileInput) fileInput.value = '';
  };

  const handleTrainingInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setCurrentTrainingEntry((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleAddOrUpdateTrainingEntry = () => {
    if (!currentTrainingEntry.title || !currentTrainingEntry.date || !currentTrainingEntry.description) {
      alert('الرجاء ملء جميع الحقول المطلوبة للتدريب.');
      return;
    }

    if (editingTrainingId) {
      setFormData((prev) => ({
        ...prev,
        trainingLog: prev.trainingLog.map((entry) =>
          entry.id === editingTrainingId ? { ...currentTrainingEntry, id: editingTrainingId } : entry
        ),
      }));
      setEditingTrainingId(null);
    } else {
      setFormData((prev) => ({
        ...prev,
        trainingLog: [...prev.trainingLog, { ...currentTrainingEntry, id: generateUniqueId() }],
      }));
    }
    setCurrentTrainingEntry({ title: '', date: '', description: '', certificateUrl: '' });
  };

  const handleEditTrainingClick = (entry: TrainingLogEntry) => {
    setCurrentTrainingEntry(entry);
    setEditingTrainingId(entry.id);
  };

  const handleDeleteTrainingEntry = (id: string) => {
    setFormData((prev) => ({
      ...prev,
      trainingLog: prev.trainingLog.filter((entry) => entry.id !== id),
    }));
    // If the deleted entry was being edited, clear the editing state
    if (editingTrainingId === id) {
      setCurrentTrainingEntry({ title: '', date: '', description: '', certificateUrl: '' });
      setEditingTrainingId(null);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit({ ...formData, id: initialData?.id || '' });
  };

  const unitOptions = dynamicConfig.units.map((unit) => ({ value: unit, label: unit }));

  const getSubUnitOptions = (unit: Unit) => {
    return (dynamicConfig.subUnits[unit] || ['غير محدد']).map(s => ({ value: s, label: s }));
  };
  const subUnitOptions = getSubUnitOptions(formData.unit);

  return (
    <NeumorphicModal isOpen={isOpen} onClose={onClose} title={initialData ? 'تعديل بيانات العضو' : 'إضافة عضو جديد'}>
      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Basic Member Info */}
        <div className="space-y-4">
          <h3 className="text-xl font-bold text-neumorphic-primary mb-3">معلومات العضو الأساسية</h3>
          <div>
            <label className="block text-gray-700 text-sm font-bold mb-2">الاسم الكامل:</label>
            <NeumorphicInput
              type="text"
              name="fullName"
              value={formData.fullName}
              onChange={handleChange}
              required
              className="w-full"
            />
          </div>
          <div>
            <label className="block text-gray-700 text-sm font-bold mb-2">تاريخ الميلاد:</label>
            <NeumorphicInput
              type="date"
              name="dateOfBirth"
              value={formData.dateOfBirth}
              onChange={handleChange}
              required
              className="w-full"
            />
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-gray-700 text-sm font-bold mb-2">الوحدة:</label>
              <NeumorphicSelect
                name="unit"
                options={unitOptions}
                value={formData.unit}
                onChange={handleUnitChange}
                className="w-full"
              />
            </div>
            <div>
              <label className="block text-gray-700 text-sm font-bold mb-2">الفرقة:</label>
              <NeumorphicSelect
                name="subUnit"
                options={subUnitOptions}
                value={formData.subUnit}
                onChange={handleChange}
                className="w-full"
              />
            </div>
          </div>
          <div>
            <label className="block text-gray-700 text-sm font-bold mb-2">المستوى التدريبي:</label>
            <NeumorphicInput
              type="text"
              name="trainingLevel"
              value={formData.trainingLevel}
              onChange={handleChange}
              required
              className="w-full"
            />
          </div>
          <div>
            <label className="block text-gray-700 text-sm font-bold mb-2">سنة التسجيل:</label>
            <NeumorphicInput
              type="number"
              name="registrationYear"
              value={formData.registrationYear}
              onChange={handleChange}
              required
              className="w-full"
            />
          </div>
          <div>
            <label className="block text-gray-700 text-sm font-bold mb-2">معلومات الاتصال:</label>
            <NeumorphicInput
              type="text"
              name="contactInfo"
              value={formData.contactInfo}
              onChange={handleChange}
              required
              className="w-full"
            />
          </div>
          <div>
            <label className="block text-gray-700 text-sm font-bold mb-2">ملاحظات:</label>
            <textarea
              name="notes"
              value={formData.notes}
              onChange={handleChange}
              rows={3}
              className="bg-neumorphic-bg rounded-lg shadow-neumorphic-in border-transparent focus:border-neumorphic-primary focus:outline-none focus:ring-2 focus:ring-neumorphic-primary transition-all duration-200 px-3 py-2 text-gray-700 placeholder-gray-500 w-full"
            ></textarea>
          </div>
          <div>
            <label className="block text-gray-700 text-sm font-bold mb-2">شارات (مفصولة بفاصلة):</label>
            <NeumorphicInput
              type="text"
              name="badgesTimeline"
              value={formData.badgesTimeline.join(', ')}
              onChange={(e) => setFormData((prev) => ({ ...prev, badgesTimeline: e.target.value.split(',').map(s => s.trim()).filter(Boolean) }))}
              className="w-full"
            />
          </div>
          {/* Profile Picture Upload */}
          <div>
            <label className="block text-gray-700 text-sm font-bold mb-2">صورة الملف الشخصي:</label>
            {formData.profilePicture && (
              <div className="mb-2 w-24 h-24 rounded-full overflow-hidden shadow-neumorphic-in flex items-center justify-center">
                <img src={formData.profilePicture} alt="Profile Preview" className="w-full h-full object-cover" />
              </div>
            )}
            <input
              id="profilePictureInput"
              type="file"
              name="profilePictureFile"
              onChange={handleFileChange}
              className="hidden" // Hide the default file input
              accept="image/*"
              aria-label="اختيار صورة للملف الشخصي"
            />
            <NeumorphicButton
              type="button"
              onClick={() => document.getElementById('profilePictureInput')?.click()}
              variant="secondary"
              className="w-full"
            >
              اختيار صورة
            </NeumorphicButton>
            {formData.profilePicture && (
              <NeumorphicButton
                type="button"
                onClick={handleClearPicture}
                variant="danger"
                className="w-full mt-2"
              >
                حذف الصورة
              </NeumorphicButton>
            )}
          </div>
        </div>

        {/* Training Log Section */}
        <div className="space-y-4 pt-4 border-t border-gray-200">
          <h3 className="text-xl font-bold text-neumorphic-primary mb-3">سجل التدريبات</h3>
          <div className="space-y-3 p-4 bg-neumorphic-bg rounded-lg shadow-neumorphic-in">
            <div>
              <label className="block text-gray-700 text-sm font-bold mb-2">عنوان التدريب:</label>
              <NeumorphicInput
                type="text"
                name="title"
                value={currentTrainingEntry.title}
                onChange={handleTrainingInputChange}
                className="w-full"
                placeholder="اسم الدورة أو الشهادة"
              />
            </div>
            <div>
              <label className="block text-gray-700 text-sm font-bold mb-2">تاريخ الإنجاز:</label>
              <NeumorphicInput
                type="date"
                name="date"
                value={currentTrainingEntry.date}
                onChange={handleTrainingInputChange}
                className="w-full"
              />
            </div>
            <div>
              <label className="block text-gray-700 text-sm font-bold mb-2">الوصف:</label>
              <textarea
                name="description"
                value={currentTrainingEntry.description}
                onChange={handleTrainingInputChange}
                rows={2}
                className="bg-neumorphic-bg rounded-lg shadow-neumorphic-in border-transparent focus:border-neumorphic-primary focus:outline-none focus:ring-2 focus:ring-neumorphic-primary transition-all duration-200 px-3 py-2 text-gray-700 placeholder-gray-500 w-full"
                placeholder="وصف موجز للتدريب"
              ></textarea>
            </div>
            <div>
              <label className="block text-gray-700 text-sm font-bold mb-2">رابط الشهادة (اختياري):</label>
              <NeumorphicInput
                type="url"
                name="certificateUrl"
                value={currentTrainingEntry.certificateUrl}
                onChange={handleTrainingInputChange}
                className="w-full"
                placeholder="https://example.com/certificate.pdf"
              />
            </div>
            <NeumorphicButton
              type="button"
              onClick={handleAddOrUpdateTrainingEntry}
              variant="primary"
              className="w-full mt-2"
              disabled={!currentTrainingEntry.title || !currentTrainingEntry.date || !currentTrainingEntry.description}
            >
              {editingTrainingId ? 'حفظ التعديل' : 'إضافة تدريب'}
            </NeumorphicButton>
            {editingTrainingId && (
              <NeumorphicButton
                type="button"
                onClick={() => {
                  setCurrentTrainingEntry({ title: '', date: '', description: '', certificateUrl: '' });
                  setEditingTrainingId(null);
                }}
                variant="secondary"
                className="w-full mt-2"
              >
                إلغاء التعديل
              </NeumorphicButton>
            )}
          </div>

          {formData.trainingLog.length > 0 && (
            <div className="mt-4 space-y-2">
              <h4 className="font-semibold text-gray-700 mb-2">التدريبات المسجلة:</h4>
              {formData.trainingLog.map((entry) => (
                <div key={entry.id} className="bg-white rounded-lg shadow-neumorphic-out p-3 flex flex-col sm:flex-row justify-between items-start sm:items-center">
                  <div className="mb-2 sm:mb-0">
                    <p className="font-bold text-neumorphic-primary">{entry.title}</p>
                    <p className="text-sm text-gray-600">التاريخ: {entry.date}</p>
                    <p className="text-sm text-gray-600">الوصف: {entry.description}</p>
                    {entry.certificateUrl && (
                      <a href={entry.certificateUrl} target="_blank" rel="noopener noreferrer" className="text-blue-500 hover:underline text-sm block mt-1">
                        عرض الشهادة
                      </a>
                    )}
                  </div>
                  <div className="flex space-x-reverse space-x-2">
                    <NeumorphicButton
                      type="button"
                      variant="secondary"
                      onClick={() => handleEditTrainingClick(entry)}
                      className="text-xs py-1 px-2"
                    >
                      تعديل
                    </NeumorphicButton>
                    <NeumorphicButton
                      type="button"
                      variant="danger"
                      onClick={() => handleDeleteTrainingEntry(entry.id)}
                      className="text-xs py-1 px-2"
                    >
                      حذف
                    </NeumorphicButton>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Form Action Buttons */}
        <div className="flex justify-end space-x-reverse space-x-2 mt-6 pt-4 border-t border-gray-200">
          <NeumorphicButton type="submit" variant="primary">
            {initialData ? 'تعديل العضو' : 'إضافة العضو'}
          </NeumorphicButton>
          <NeumorphicButton type="button" variant="secondary" onClick={onClose}>
            إلغاء
          </NeumorphicButton>
        </div>
      </form>
    </NeumorphicModal>
  );
}
