import React, { useContext, useState } from 'react';
import { AppContext, AppContextType } from '../../App';
import { NeumorphicButton } from '../common/NeumorphicButton';
import { NeumorphicInput } from '../common/NeumorphicInput'; // Corrected path

export function Navbar() {
  const context = useContext(AppContext);
  const [searchTerm, setSearchTerm] = useState('');

  if (!context) {
    throw new Error("Navbar must be used within an AppContext.Provider");
  }

  const { isAdmin, toggleAdminMode, addNotification } = context as AppContextType;

  const handleSearch = () => {
    addNotification({
      type: 'info',
      message: `تم البحث عن: "${searchTerm}". (هذه ميزة بحث عامة، وستقوم بتصفية جميع الوحدات).`,
    });
    console.log("Searching for:", searchTerm);
  };

  return (
    <nav className="flex flex-col md:flex-row items-center justify-between p-4 bg-neumorphic-bg rounded-xl shadow-neumorphic-out mb-6">
      <h1 className="text-2xl font-bold text-neumorphic-primary mb-4 md:mb-0 md:ml-4">
        تطبيق إدارة وتسيير ومحاسبة فوج سيدي بوعلي
      </h1>

      <div className="flex items-center space-x-reverse space-x-4 w-full md:w-auto mt-4 md:mt-0">
        <div className="relative flex-grow md:flex-grow-0">
          <NeumorphicInput
            type="text"
            placeholder="بحث..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
            className="w-full pl-10"
          />
          <button
            onClick={handleSearch}
            className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-neumorphic-primary focus:outline-none"
            aria-label="بحث"
            type="button"
          >
            🔍
          </button>
        </div>

        <NeumorphicButton
          onClick={toggleAdminMode}
          className={`py-2 px-4 text-sm whitespace-nowrap ${isAdmin ? 'bg-neumorphic-primary text-white' : 'bg-neumorphic-secondary text-white'}`}
          type="button"
        >
          {isAdmin ? 'وضع الإدارة' : 'وضع المشاهدة'}
        </NeumorphicButton>
      </div>
    </nav>
  );
}