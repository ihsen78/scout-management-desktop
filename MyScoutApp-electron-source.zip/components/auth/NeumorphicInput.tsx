import React from 'react';

interface CustomNeumorphicInputProps {
  className?: string;
}

export type NeumorphicInputProps = CustomNeumorphicInputProps & React.ComponentPropsWithoutRef<'input'>;

export function NeumorphicInput({ className = '', ...props }: NeumorphicInputProps) {
  return (
    <input
      className={`bg-neumorphic-bg rounded-lg shadow-neumorphic-in border-transparent focus:border-neumorphic-primary focus:outline-none focus:ring-2 focus:ring-neumorphic-primary transition-all duration-200 px-3 py-2 text-gray-700 placeholder-gray-500 ${className}`}
      {...props}
    />
  );
}