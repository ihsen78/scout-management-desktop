

import React, { useState, useContext } from 'react';
import { AppContext } from '../../App';
import { Document, DocumentType, DocumentRecipient } from '../../types';
import { NeumorphicButton } from '../common/NeumorphicButton';
import { NeumorphicInput } from '../common/NeumorphicInput';
import { NeumorphicSelect } from '../common/NeumorphicSelect';
import { DocumentForm } from './DocumentForm';
import { generateUniqueId } from '../../utils/idGenerator';
import { exportToPdf } from '../../utils/pdfExport';
import { exportToExcel } from '../../utils/excelExport';

export function AdministrativeRequests() {
  const context = useContext(AppContext);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingDocument, setEditingDocument] = useState<Document | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState<DocumentType | ''>('');
  const [filterStatus, setFilterStatus] = useState<'صادر' | 'وارد' | 'مسودة' | ''>('');
  const [filterYear, setFilterYear] = useState<string>(''); // New state for scouting year filter


  if (!context) {
    throw new Error("AdministrativeRequests must be used within an AppContext.Provider");
  }

  const { documents, setDocuments, addNotification, isAdmin, dynamicConfig } = context;

  // Initialize filterYear to the latest scouting year from dynamicConfig
  React.useEffect(() => {
    if (dynamicConfig.scoutingYears.length > 0) {
      setFilterYear(dynamicConfig.scoutingYears[dynamicConfig.scoutingYears.length - 1]);
    }
  }, [dynamicConfig.scoutingYears]);

  const handleAddOrUpdateDocument = (newDocument: Document) => {
    if (editingDocument) {
      setDocuments(documents.map((d) => (d.id === newDocument.id ? newDocument : d)));
      addNotification({ type: 'success', message: 'تم تحديث الوثيقة بنجاح.' });
    } else {
      setDocuments([...documents, { ...newDocument, id: generateUniqueId() }]);
      addNotification({ type: 'success', message: 'تمت إضافة وثيقة جديدة بنجاح.' });
    }
    setIsModalOpen(false);
    setEditingDocument(null);
  };

  const handleDeleteDocument = (id: string) => {
    if (!isAdmin) {
      addNotification({ type: 'error', message: 'ليس لديك صلاحية لحذف الوثائق.' });
      return;
    }
    if (window.confirm('هل أنت متأكد من حذف هذه الوثيقة؟')) {
      setDocuments(documents.filter((d) => d.id !== id));
      addNotification({ type: 'success', message: 'تم حذف الوثيقة بنجاح.' });
    }
  };

  const openEditModal = (document: Document) => {
    if (!isAdmin) {
      addNotification({ type: 'error', message: 'ليس لديك صلاحية لتعديل الوثائق.' });
      return;
    }
    setEditingDocument(document);
    setIsModalOpen(true);
  };

  const filteredDocuments = documents.filter((doc) => {
    const matchesSearch = doc.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          doc.notes.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          doc.content.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesType = filterType === '' || doc.type === filterType;
    const matchesStatus = filterStatus === '' || doc.status === filterStatus;
    
    // Filter by scouting year
    let matchesYear = true;
    if (filterYear) {
      const [startYearStr, endYearStr] = filterYear.split('-');
      const startYear = parseInt(startYearStr);
      const endYear = parseInt(endYearStr);
      
      const yearStartDate = new Date(startYear, 8, 1); // September 1st of the start year
      const yearEndDate = new Date(endYear, 7, 31);   // August 31st of the end year

      const documentDate = new Date(doc.date);
      matchesYear = documentDate >= yearStartDate && documentDate <= yearEndDate;
    }

    return matchesSearch && matchesType && matchesStatus && matchesYear;
  }).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()); // Sort by date desc

  const documentTypeOptions = [{ value: '', label: 'جميع الأنواع' }, ...dynamicConfig.documentTypes.map((type) => ({ value: type, label: type }))];
  const documentStatusOptions = [
    { value: '', label: 'جميع الحالات' },
    { value: 'صادر', label: 'صادر' },
    { value: 'وارد', label: 'وارد' },
    { value: 'مسودة', label: 'مسودة' },
  ];
  const scoutingYearOptions = dynamicConfig.scoutingYears.map(year => ({ value: year, label: `العام الكشفي ${year}` }));


  const handlePrintDocument = (doc: Document) => {
    const content = `
      <div style="font-family: Arial, sans-serif; direction: rtl; text-align: right; padding: 20px;">
        <h1 style="text-align: center; color: #6a82fb;">${doc.title}</h1>
        <p style="text-align: center; color: #555;">نوع الوثيقة: ${doc.type}</p>
        <p style="text-align: center; color: #555;">التاريخ: ${doc.date}</p>
        <p style="text-align: center; color: #555;">المرسل إليه/المرسل: ${doc.recipient}</p>
        <p style="text-align: center; color: #555;">الحالة: ${doc.status}</p>
        ${filterYear ? `<p style="text-align: center; color: #555;">العام الكشفي: ${filterYear}</p>` : ''}
        <hr style="margin: 20px 0; border: 0; border-top: 1px solid #eee;">
        <div style="margin-top: 20px; line-height: 1.6; color: #333;">
          ${doc.content.replace(/\n/g, '<br/>')}
        </div>
        <hr style="margin: 20px 0; border: 0; border-top: 1px solid #eee;">
        <p style="color: #777;">ملاحظات: ${doc.notes || 'لا توجد'}</p>
        <p style="color: #777;">تاريخ الأرشفة: ${doc.archiveDate || 'لم تتم الأرشفة بعد'}</p>
      </div>
    `;
    exportToPdf(content, `${doc.title}-${filterYear}.pdf`);
    addNotification({ type: 'success', message: `تم تصدير الوثيقة "${doc.title}" إلى PDF.` });
  };

  const handleExportExcel = () => {
    if (filteredDocuments.length === 0) {
      addNotification({ type: 'warning', message: 'لا توجد بيانات لتصديرها إلى Excel.' });
      return;
    }
    const headers = ['العنوان', 'النوع', 'التاريخ', 'الجهة', 'الحالة', 'المحتوى', 'تاريخ الأرشفة', 'ملاحظات', 'العام الكشفي'];
    const data = filteredDocuments.map(doc => [
      doc.title,
      doc.type,
      doc.date,
      doc.recipient,
      doc.status,
      doc.content,
      doc.archiveDate,
      doc.notes,
      filterYear,
    ]);
    exportToExcel(headers, data, `الوثائق-الإدارية-${filterYear}-الكشافة-التونسية.xlsx`);
    addNotification({ type: 'success', message: 'تم تصدير الوثائق الإدارية إلى Excel.' });
  };


  return (
    <div className="p-4 rounded-xl"> {/* Removed bg-gradient-to-br from-neumorphic-light to-neumorphic-bg shadow-neumorphic-out as it's now handled by App.tsx main */}
      <div className="flex flex-col md:flex-row items-center justify-between mb-6 space-y-4 md:space-y-0 md:space-x-reverse md:space-x-4">
        <NeumorphicInput
          type="text"
          placeholder="ابحث عن وثيقة (العنوان، المحتوى، الملاحظات)..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full md:flex-grow"
        />
        <NeumorphicSelect
          options={documentTypeOptions}
          value={filterType}
          onChange={(e) => setFilterType(e.target.value as DocumentType | '')}
          className="w-full md:w-1/4"
        />
        <NeumorphicSelect
          options={documentStatusOptions}
          value={filterStatus}
          onChange={(e) => setFilterStatus(e.target.value as 'صادر' | 'وارد' | 'مسودة' | '')}
          className="w-full md:w-1/4"
        />
        <NeumorphicSelect
          options={scoutingYearOptions}
          value={filterYear}
          onChange={(e) => setFilterYear(e.target.value)}
          className="w-full md:w-1/4"
        />
        <div className="flex space-x-reverse space-x-2 w-full md:w-auto">
          {isAdmin && (
            <React.Fragment>
              <NeumorphicButton onClick={() => { setEditingDocument(null); setIsModalOpen(true); }} className="w-full md:w-auto" type="button">
                إضافة وثيقة جديدة
              </NeumorphicButton>
            </React.Fragment>
          )}
          <NeumorphicButton onClick={handleExportExcel} variant="secondary" className="w-1/2 md:w-auto text-sm" type="button">
            تصدير Excel
          </NeumorphicButton>
        </div>
      </div>

      <div className="space-y-4">
        {filteredDocuments.length === 0 ? (
          <p className="text-center text-gray-600">لا توجد وثائق مطابقة لمعايير البحث أو التصفية.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="min-w-full bg-white rounded-lg shadow-md overflow-hidden text-right">
              <thead className="bg-gray-100">
                <tr>
                  <th scope="col" className="py-2 px-4 border-b">العنوان</th>
                  <th scope="col" className="py-2 px-4 border-b">النوع</th>
                  <th scope="col" className="py-2 px-4 border-b">التاريخ</th>
                  <th scope="col" className="py-2 px-4 border-b">الجهة</th>
                  <th scope="col" className="py-2 px-4 border-b">الحالة</th>
                  <th scope="col" className="py-2 px-4 border-b">تاريخ الأرشفة</th>
                  <th scope="col" className="py-2 px-4 border-b">ملاحظات</th>
                  {isAdmin && <th scope="col" className="py-2 px-4 border-b">إجراءات</th>}
                </tr>
              </thead>
              <tbody>
                {filteredDocuments.map((doc) => (
                  <tr key={doc.id} className="hover:bg-gray-50">
                    <td className="py-2 px-4 border-b text-gray-700 font-bold">{doc.title}</td>
                    <td className="py-2 px-4 border-b text-gray-700">{doc.type}</td>
                    <td className="py-2 px-4 border-b text-gray-700">{doc.date}</td>
                    <td className="py-2 px-4 border-b text-gray-700">{doc.recipient}</td>
                    <td className="py-2 px-4 border-b text-gray-700">{doc.status}</td>
                    <td className="py-2 px-4 border-b text-gray-700">{doc.archiveDate || 'لم تتم الأرشفة'}</td>
                    <td className="py-2 px-4 border-b text-gray-700 line-clamp-2">{doc.notes || 'لا توجد ملاحظات.'}</td>
                    {isAdmin && (
                      <td className="py-2 px-4 border-b">
                        <div className="flex justify-end mt-0 space-x-reverse space-x-2">
                          <NeumorphicButton variant="secondary" onClick={() => openEditModal(doc)} className="text-xs py-1 px-2" type="button">
                            تعديل
                          </NeumorphicButton>
                          <NeumorphicButton variant="secondary" onClick={() => handlePrintDocument(doc)} className="text-xs py-1 px-2" type="button">
                            طباعة/PDF
                          </NeumorphicButton>
                          <NeumorphicButton variant="danger" onClick={() => handleDeleteDocument(doc.id)} className="text-xs py-1 px-2" type="button">
                            حذف
                          </NeumorphicButton>
                        </div>
                      </td>
                    )}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      <DocumentForm
        isOpen={isModalOpen}
        onClose={() => { setIsModalOpen(false); setEditingDocument(null); }}
        onSubmit={handleAddOrUpdateDocument}
        initialData={editingDocument}
      />
    </div>
  );
}