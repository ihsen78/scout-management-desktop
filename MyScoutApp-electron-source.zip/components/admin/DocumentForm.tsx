
import React, { useState, useEffect, useContext } from 'react';
import { Document, DocumentType, DocumentRecipient } from '../../types';
import { NeumorphicModal } from '../common/NeumorphicModal';
import { NeumorphicInput } from '../common/NeumorphicInput';
import { NeumorphicSelect } from '../common/NeumorphicSelect';
import { NeumorphicButton } from '../common/NeumorphicButton';
import { AppContext } from '../../App';

interface DocumentFormProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (document: Document) => void;
  initialData?: Document | null;
}

export function DocumentForm({ isOpen, onClose, onSubmit, initialData }: DocumentFormProps) {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error("DocumentForm must be used within an AppContext.Provider");
  }
  const { dynamicConfig } = context;

  const [formData, setFormData] = useState<Omit<Document, 'id'>>({
    title: '',
    type: dynamicConfig.documentTypes[0] || '', // Default to first available document type
    date: '',
    recipient: dynamicConfig.documentRecipients[0] || '', // Default to first available recipient
    status: 'مسودة',
    content: '',
    archiveDate: '',
    notes: '',
  });

  useEffect(() => {
    if (initialData) {
      setFormData(initialData);
    } else {
      setFormData({
        title: '',
        type: dynamicConfig.documentTypes[0] || '',
        date: new Date().toISOString().split('T')[0],
        recipient: dynamicConfig.documentRecipients[0] || '',
        status: 'مسودة',
        content: '',
        archiveDate: '',
        notes: '',
      });
    }
  }, [initialData, isOpen, dynamicConfig.documentTypes, dynamicConfig.documentRecipients]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit({ ...formData, id: initialData?.id || '' });
  };

  const documentTypeOptions = dynamicConfig.documentTypes.map((type) => ({ value: type, label: type }));
  const documentRecipientOptions = dynamicConfig.documentRecipients.map((recipient) => ({ value: recipient, label: recipient }));
  const documentStatusOptions = [
    { value: 'صادر', label: 'صادر' },
    { value: 'وارد', label: 'وارد' },
    { value: 'مسودة', label: 'مسودة' },
  ];

  return (
    <NeumorphicModal isOpen={isOpen} onClose={onClose} title={initialData ? 'تعديل وثيقة' : 'إضافة وثيقة جديدة'}>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-gray-700 text-sm font-bold mb-2">العنوان:</label>
          <NeumorphicInput
            type="text"
            name="title"
            value={formData.title}
            onChange={handleChange}
            required
            className="w-full"
          />
        </div>
        <div>
          <label className="block text-gray-700 text-sm font-bold mb-2">النوع:</label>
          <NeumorphicSelect
            name="type"
            options={documentTypeOptions}
            value={formData.type}
            onChange={handleChange}
            required
            className="w-full"
          />
        </div>
        <div>
          <label className="block text-gray-700 text-sm font-bold mb-2">التاريخ:</label>
          <NeumorphicInput
            type="date"
            name="date"
            value={formData.date}
            onChange={handleChange}
            required
            className="w-full"
          />
        </div>
        <div>
          <label className="block text-gray-700 text-sm font-bold mb-2">الجهة المرسل إليها / المرسل:</label>
          <NeumorphicSelect
            name="recipient"
            options={documentRecipientOptions}
            value={formData.recipient}
            onChange={handleChange}
            required
            className="w-full"
          />
        </div>
        <div>
          <label className="block text-gray-700 text-sm font-bold mb-2">الحالة:</label>
          <NeumorphicSelect
            name="status"
            options={documentStatusOptions}
            value={formData.status}
            onChange={handleChange}
            required
            className="w-full"
          />
        </div>
        <div>
          <label className="block text-gray-700 text-sm font-bold mb-2">المحتوى:</label>
          <textarea
            name="content"
            value={formData.content}
            onChange={handleChange}
            rows={6}
            required
            className="bg-neumorphic-bg rounded-lg shadow-neumorphic-in border-transparent focus:border-neumorphic-primary focus:outline-none focus:ring-2 focus:ring-neumorphic-primary transition-all duration-200 px-3 py-2 text-gray-700 placeholder-gray-500 w-full"
          ></textarea>
        </div>
        <div>
          <label className="block text-gray-700 text-sm font-bold mb-2">تاريخ الأرشفة (اختياري):</label>
          <NeumorphicInput
            type="date"
            name="archiveDate"
            value={formData.archiveDate}
            onChange={handleChange}
            className="w-full"
          />
        </div>
        <div>
          <label className="block text-gray-700 text-sm font-bold mb-2">ملاحظات:</label>
          <textarea
            name="notes"
            value={formData.notes}
            onChange={handleChange}
            rows={3}
            className="bg-neumorphic-bg rounded-lg shadow-neumorphic-in border-transparent focus:border-neumorphic-primary focus:outline-none focus:ring-2 focus:ring-neumorphic-primary transition-all duration-200 px-3 py-2 text-gray-700 placeholder-gray-500 w-full"
          ></textarea>
        </div>
        <div className="flex justify-end space-x-reverse space-x-2 mt-6">
          <NeumorphicButton type="submit" variant="primary">
            {initialData ? 'تعديل' : 'إضافة'}
          </NeumorphicButton>
          <NeumorphicButton type="button" variant="secondary" onClick={onClose}>
            إلغاء
          </NeumorphicButton>
        </div>
      </form>
    </NeumorphicModal>
  );
}
