
import React, { useState, useContext } from 'react';
import { AppContext } from '../../App';
import { NeumorphicButton } from '../common/NeumorphicButton';
import { NeumorphicInput } from '../common/NeumorphicInput';
import { NeumorphicSelect } from '../common/NeumorphicSelect';
import { NeumorphicCard } from '../common/NeumorphicCard';
import { NeumorphicModal } from '../common/NeumorphicModal';
import { generateUniqueId } from '../../utils/idGenerator';
import { Unit } from '../../types'; // Just for type hint now

type SettingsTab = 'units' | 'subUnits' | 'activityTypes' | 'revenueCategories' | 'expenseCategories' | 'scoutingYears' |'documentTypes' | 'documentRecipients' | 'scoutingYears' ;

export function SettingsManagement() {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error("SettingsManagement must be used within an AppContext.Provider");
  }
  const {
    dynamicConfig, setDynamicConfig, addNotification, isAdmin,
    members, setMembers, activities, setActivities, financialRecords, setFinancialRecords, documents, setDocuments,
  } = context;

  const [activeTab, setActiveTab] = useState<SettingsTab>('units');
  const [newValue, setNewValue] = useState('');
  const [editingValue, setEditingValue] = useState<string | null>(null);
  const [selectedUnitForSubUnit, setSelectedUnitForSubUnit] = useState<Unit | ''>(dynamicConfig.units[0] || '');

  // Modal for editing
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [currentEditCategory, setCurrentEditCategory] = useState<SettingsTab | null>(null);
  const [currentEditOldValue, setCurrentEditOldValue] = useState('');
  const [currentEditNewValue, setCurrentEditNewValue] = useState('');
  const [currentEditSubUnitParentUnit, setCurrentEditSubUnitParentUnit] = useState<Unit | null>(null);

  const getCategoryList = (tab: SettingsTab) => {
    switch (tab) {
      case 'units': return dynamicConfig.units;
      case 'subUnits': return dynamicConfig.subUnits[selectedUnitForSubUnit as Unit] || [];
      case 'activityTypes': return dynamicConfig.activityTypes;
      case 'revenueCategories': return dynamicConfig.revenueCategories;
      case 'expenseCategories': return dynamicConfig.expenseCategories;
      case 'documentTypes': return dynamicConfig.documentTypes;
      case 'documentRecipients': return dynamicConfig.documentRecipients;
      default: return [];
    }
  };

  const setCategoryList = (tab: SettingsTab, newList: string[] | Record<string, string[]>) => {
    setDynamicConfig((prevConfig) => {
      const newConfig = { ...prevConfig };
      switch (tab) {
        case 'units': newConfig.units = newList as string[]; break;
        case 'subUnits': newConfig.subUnits = newList as Record<string, string[]>; break;
        case 'activityTypes': newConfig.activityTypes = newList as string[]; break;
        case 'revenueCategories': newConfig.revenueCategories = newList as string[]; break;
        case 'expenseCategories': newConfig.expenseCategories = newList as string[]; break;
        case 'documentTypes': newConfig.documentTypes = newList as string[]; break;
        case 'documentRecipients': newConfig.documentRecipients = newList as string[]; break;
      }
      return newConfig;
    });
  };

  const handleAdd = () => {
    if (!newValue.trim()) {
      addNotification({ type: 'warning', message: 'الرجاء إدخال قيمة.' });
      return;
    }
    const list = getCategoryList(activeTab);
    if (list.includes(newValue.trim())) {
      addNotification({ type: 'warning', message: 'هذه القيمة موجودة بالفعل.' });
      return;
    }

    setDynamicConfig((prevConfig) => {
      const newConfig = { ...prevConfig };
      if (activeTab === 'subUnits') {
        // Handle subUnits
        if (selectedUnitForSubUnit) {
          newConfig.subUnits = {
            ...newConfig.subUnits,
            [selectedUnitForSubUnit]: [...(newConfig.subUnits[selectedUnitForSubUnit] || []), newValue.trim()],
          };
        }
      } else {
        setCategoryList(activeTab, [...list, newValue.trim()]);
      }
      return newConfig;
    });

    addNotification({ type: 'success', message: 'تم إضافة القيمة بنجاح.' });
    setNewValue('');
  };

  const handleEditOpen = (category: SettingsTab, oldValue: string, parentUnit: Unit | null = null) => {
    if (!isAdmin) {
      addNotification({ type: 'error', message: 'ليس لديك صلاحية لتعديل الإعدادات.' });
      return;
    }
    setCurrentEditCategory(category);
    setCurrentEditOldValue(oldValue);
    setCurrentEditNewValue(oldValue);
    setCurrentEditSubUnitParentUnit(parentUnit);
    setIsEditModalOpen(true);
  };

  const handleEditSave = () => {
    if (!currentEditNewValue.trim()) {
      addNotification({ type: 'warning', message: 'الرجاء إدخال قيمة جديدة.' });
      return;
    }
    const list = getCategoryList(currentEditCategory!);
    if (list.includes(currentEditNewValue.trim()) && currentEditNewValue.trim() !== currentEditOldValue) {
      addNotification({ type: 'warning', message: 'هذه القيمة موجودة بالفعل.' });
      return;
    }

    setDynamicConfig((prevConfig) => {
      const newConfig = { ...prevConfig };

      if (currentEditCategory === 'subUnits' && currentEditSubUnitParentUnit) {
        newConfig.subUnits = {
          ...newConfig.subUnits,
          [currentEditSubUnitParentUnit]: (newConfig.subUnits[currentEditSubUnitParentUnit] || []).map(val =>
            val === currentEditOldValue ? currentEditNewValue.trim() : val
          ),
        };
        // Update members using this sub-unit
        // Fix: Use setMembers to update the members state
        setMembers(members.map(member => {
          if (member.unit === currentEditSubUnitParentUnit && member.subUnit === currentEditOldValue) {
            return { ...member, subUnit: currentEditNewValue.trim() };
          }
          return member;
        }));
      } else {
        // Update the category list
        const updatedList = list.map(val => (val === currentEditOldValue ? currentEditNewValue.trim() : val));
        setCategoryList(currentEditCategory!, updatedList);

        // Update records that use this category
        switch (currentEditCategory) {
          case 'units':
            // Fix: Use setMembers to update the members state
            setMembers(members.map(member => {
              if (member.unit === currentEditOldValue) return { ...member, unit: currentEditNewValue.trim() };
              return member;
            }));
            // Fix: Use setActivities to update the activities state
            setActivities(activities.map(activity => {
              return {
                ...activity,
                unitInvolved: activity.unitInvolved.map(unit =>
                  unit === currentEditOldValue ? currentEditNewValue.trim() : unit
                ),
              };
            }));
            // Also update subUnits keys if a unit name changes
            if (newConfig.subUnits[currentEditOldValue]) {
              newConfig.subUnits[currentEditNewValue.trim()] = newConfig.subUnits[currentEditOldValue];
              delete newConfig.subUnits[currentEditOldValue];
            }
            break;
          case 'activityTypes':
            // Fix: Use setActivities to update the activities state
            setActivities(activities.map(activity => {
              if (activity.type === currentEditOldValue) return { ...activity, type: currentEditNewValue.trim() };
              return activity;
            }));
            break;
          case 'revenueCategories':
            // Fix: Use setFinancialRecords to update the financialRecords state
            setFinancialRecords(financialRecords.map(record => {
              if (record.type === 'revenue' && record.category === currentEditOldValue) return { ...record, category: currentEditNewValue.trim() };
              return record;
            }));
            break;
          case 'expenseCategories':
            // Fix: Use setFinancialRecords to update the financialRecords state
            setFinancialRecords(financialRecords.map(record => {
              if (record.type === 'expense' && record.category === currentEditOldValue) return { ...record, category: currentEditNewValue.trim() };
              return record;
            }));
            break;
          case 'documentTypes':
            // Fix: Use setDocuments to update the documents state
            setDocuments(documents.map(doc => {
              if (doc.type === currentEditOldValue) return { ...doc, type: currentEditNewValue.trim() };
              return doc;
            }));
            break;
          case 'documentRecipients':
            // Fix: Use setDocuments to update the documents state
            setDocuments(documents.map(doc => {
              if (doc.recipient === currentEditOldValue) return { ...doc, recipient: currentEditNewValue.trim() };
              return doc;
            }));
            break;
        }
      }
      return newConfig;
    });

    addNotification({ type: 'success', message: 'تم تحديث القيمة بنجاح.' });
    setIsEditModalOpen(false);
    setEditingValue(null);
  };

  const handleDelete = (valueToDelete: string, parentUnit: Unit | null = null) => {
    if (!isAdmin) {
      addNotification({ type: 'error', message: 'ليس لديك صلاحية لحذف الإعدادات.' });
      return;
    }

    // Check for dependencies before deleting
    let isInUse = false;
    switch (activeTab) {
      case 'units':
        isInUse = members.some(m => m.unit === valueToDelete) || activities.some(a => a.unitInvolved.includes(valueToDelete));
        if (dynamicConfig.subUnits[valueToDelete] && dynamicConfig.subUnits[valueToDelete].length > 0) {
          addNotification({ type: 'error', message: `لا يمكن حذف الوحدة "${valueToDelete}" لأنها تحتوي على فرق فرعية. الرجاء حذف الفرق الفرعية أولاً.` });
          return;
        }
        break;
      case 'subUnits':
        isInUse = members.some(m => m.unit === parentUnit && m.subUnit === valueToDelete);
        break;
      case 'activityTypes':
        isInUse = activities.some(a => a.type === valueToDelete);
        break;
      case 'revenueCategories':
        isInUse = financialRecords.some(r => r.type === 'revenue' && r.category === valueToDelete);
        break;
      case 'expenseCategories':
        isInUse = financialRecords.some(r => r.type === 'expense' && r.category === valueToDelete);
        break;
      case 'documentTypes':
        isInUse = documents.some(d => d.type === valueToDelete);
        break;
      case 'documentRecipients':
        isInUse = documents.some(d => d.recipient === valueToDelete);
        break;
    }

    if (isInUse) {
      addNotification({ type: 'error', message: `لا يمكن حذف "${valueToDelete}" لأنه مستخدم في سجلات موجودة.` });
      return;
    }

    if (!window.confirm(`هل أنت متأكد من حذف "${valueToDelete}"؟`)) return;

    setDynamicConfig((prevConfig) => {
      const newConfig = { ...prevConfig };
      if (activeTab === 'subUnits' && parentUnit) {
        newConfig.subUnits = {
          ...newConfig.subUnits,
          [parentUnit]: (newConfig.subUnits[parentUnit] || []).filter(val => val !== valueToDelete),
        };
      } else {
        const updatedList = getCategoryList(activeTab).filter(val => val !== valueToDelete);
        setCategoryList(activeTab, updatedList);

        // If a unit is deleted, also remove its sub-units
        if (activeTab === 'units') {
          delete newConfig.subUnits[valueToDelete];
        }
      }
      return newConfig;
    });
    addNotification({ type: 'success', message: 'تم حذف القيمة بنجاح.' });
  };


  const renderCategoryManagement = (tab: SettingsTab, label: string, isSubUnitTab = false) => (
    <NeumorphicCard className="mb-6 p-4">
      <h3 className="text-xl font-bold text-neumorphic-primary mb-4">{label}</h3>
      {isSubUnitTab && (
        <div className="mb-4">
          <label className="block text-gray-700 text-sm font-bold mb-2">اختر الوحدة:</label>
          <NeumorphicSelect
            options={dynamicConfig.units.map(unit => ({ value: unit, label: unit }))}
            value={selectedUnitForSubUnit}
            onChange={(e) => setSelectedUnitForSubUnit(e.target.value as Unit)}
            className="w-full"
            disabled={!isAdmin}
          />
        </div>
      )}

      {(!isSubUnitTab || selectedUnitForSubUnit) && (
        <>
          <div className="flex mb-4 space-x-reverse space-x-2">
            <NeumorphicInput
              type="text"
              placeholder={`أضف ${label} جديد...`}
              value={newValue}
              onChange={(e) => setNewValue(e.target.value)}
              className="flex-grow"
              disabled={!isAdmin}
            />
            {isAdmin && (
              <NeumorphicButton onClick={handleAdd} type="button" variant="primary">
                إضافة
              </NeumorphicButton>
            )}
          </div>

          <div className="space-y-2">
            {getCategoryList(tab).length === 0 ? (
              <p className="text-gray-600 text-center">لا توجد قيم لهذه الفئة.</p>
            ) : (
              getCategoryList(tab).map((item, index) => (
                <div key={item + index} className="flex justify-between items-center bg-white p-3 rounded-lg shadow-neumorphic-out">
                  <span className="font-semibold text-gray-800">{item}</span>
                  {isAdmin && (
                    <div className="flex space-x-reverse space-x-2">
                      <NeumorphicButton
                        variant="secondary"
                        className="text-xs py-1 px-2"
                        onClick={() => handleEditOpen(tab, item, isSubUnitTab ? selectedUnitForSubUnit : null)}
                        type="button"
                      >
                        تعديل
                      </NeumorphicButton>
                      <NeumorphicButton
                        variant="danger"
                        className="text-xs py-1 px-2"
                        onClick={() => handleDelete(item, isSubUnitTab ? selectedUnitForSubUnit : null)}
                        type="button"
                      >
                        حذف
                      </NeumorphicButton>
                    </div>
                  )}
                </div>
              ))
            )}
          </div>
        </>
      )}
    </NeumorphicCard>
  );

  return (
    <div className="p-4 rounded-xl">
      <h2 className="text-2xl font-bold text-neumorphic-primary mb-6 text-center">إدارة إعدادات التطبيق</h2>

      <div className="flex overflow-x-auto whitespace-nowrap mb-6 p-2 bg-neumorphic-bg rounded-xl shadow-neumorphic-out">
        {[
          { id: 'units', label: 'الوحدات' },
          { id: 'subUnits', label: 'الفرق الفرعية' },
          { id: 'activityTypes', label: 'أنواع الأنشطة' },
          { id: 'revenueCategories', label: 'فئات المداخيل' },
          { id: 'expenseCategories', label: 'فئات المصاريف' },
          { id: 'documentTypes', label: 'أنواع الوثائق' },
          { id: 'documentRecipients', label: 'مستلمو الوثائق' },
        ].map((tabInfo) => (
          <NeumorphicButton
            key={tabInfo.id}
            onClick={() => setActiveTab(tabInfo.id as SettingsTab)}
            className={`flex-shrink-0 mx-1 px-4 py-2 text-sm font-bold transition-all duration-200 ${
              activeTab === tabInfo.id ? 'bg-neumorphic-primary text-white shadow-neumorphic-button-in' : 'bg-neumorphic-bg text-gray-700'
            }`}
            variant={activeTab === tabInfo.id ? 'primary' : 'secondary'}
            type="button"
          >
            {tabInfo.label}
          </NeumorphicButton>
        ))}
      </div>

      <div className="mt-6">
        {activeTab === 'units' && renderCategoryManagement('units', 'الوحدات')}
        {activeTab === 'subUnits' && renderCategoryManagement('subUnits', 'الفرق الفرعية', true)}
        {activeTab === 'activityTypes' && renderCategoryManagement('activityTypes', 'أنواع الأنشطة')}
        {activeTab === 'revenueCategories' && renderCategoryManagement('revenueCategories', 'فئات المداخيل')}
        {activeTab === 'expenseCategories' && renderCategoryManagement('expenseCategories', 'فئات المصاريف')}
        {activeTab === 'documentTypes' && renderCategoryManagement('documentTypes', 'أنواع الوثائق')}
        {activeTab === 'documentRecipients' && renderCategoryManagement('documentRecipients', 'مستلمو الوثائق')}
      </div>

      <NeumorphicModal
        isOpen={isEditModalOpen}
        onClose={() => setIsEditModalOpen(false)}
        title={`تعديل قيمة: ${currentEditOldValue}`}
      >
        <div className="space-y-4">
          <div>
            <label className="block text-gray-700 text-sm font-bold mb-2">القيمة الجديدة:</label>
            <NeumorphicInput
              type="text"
              value={currentEditNewValue}
              onChange={(e) => setCurrentEditNewValue(e.target.value)}
              className="w-full"
            />
          </div>
          <div className="flex justify-end space-x-reverse space-x-2">
            <NeumorphicButton onClick={handleEditSave} variant="primary" type="button">
              حفظ التعديل
            </NeumorphicButton>
            <NeumorphicButton onClick={() => setIsEditModalOpen(false)} variant="secondary" type="button">
              إلغاء
            </NeumorphicButton>
          </div>
        </div>
      </NeumorphicModal>
    </div>
  );
}