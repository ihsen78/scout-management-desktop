

import React, { useState, useEffect, createContext, useCallback } from 'react';
import { Navbar } from './components/layout/Navbar';
import { NotificationToast } from './components/common/NotificationToast';
import {
  Member, Activity, FinancialRecord, Document, Notification, AppData, Unit, SubUnit,
  ActivityType, RevenueCategory, ExpenseCategory, DocumentType, DocumentRecipient,
  initialAppData,
} from './types';
import { loadData, saveData } from './services/localStorageService';

// Re-imported individual management components
import { MemberManagement } from './components/members/MemberManagement';
import { TrainingLevelTracking } from './components/training/TrainingLevelTracking';
import { ActivitiesManagement } from './components/activities/ActivitiesManagement';
import { FinancialManagement } from './components/finance/FinancialManagement';
import { AdministrativeRequests } from './components/admin/AdministrativeRequests';
import { NeumorphicButton } from './components/common/NeumorphicButton';
import { SettingsManagement } from './components/admin/SettingsManagement';


// Define context types for better type safety
export interface AppContextType {
  members: Member[];
  setMembers: React.Dispatch<React.SetStateAction<Member[]>>;
  activities: Activity[];
  setActivities: React.Dispatch<React.SetStateAction<Activity[]>>;
  financialRecords: FinancialRecord[];
  setFinancialRecords: React.Dispatch<React.SetStateAction<FinancialRecord[]>>;
  documents: Document[];
  setDocuments: React.Dispatch<React.SetStateAction<Document[]>>;
  addNotification: (notification: Omit<Notification, 'id'>) => void;
  isAdmin: boolean;
  toggleAdminMode: () => void;
  getUnitIcon: (unit: Unit) => string;
  // Dynamic Config
  dynamicConfig: {
    units: Unit[];
    subUnits: Record<Unit, SubUnit[]>;
    activityTypes: ActivityType[];
    revenueCategories: RevenueCategory[];
    expenseCategories: ExpenseCategory[];
    documentTypes: DocumentType[];
    documentRecipients: DocumentRecipient[];
    scoutingYears: string[];
  };
  setDynamicConfig: React.Dispatch<React.SetStateAction<AppData['dynamicConfig']>>;
}

export const AppContext = createContext<AppContextType | undefined>(undefined);

// Define a type for the active main tab
type MainTab = 'members' | 'training' | 'activities' | 'finance' | 'admin';
type AdminSubTab = 'requests' | 'settings';

function App() {
  const [members, setMembers] = useState<Member[]>([]);
  const [activities, setActivities] = useState<Activity[]>([]);
  const [financialRecords, setFinancialRecords] = useState<FinancialRecord[]>([]);
  const [documents, setDocuments] = useState<Document[]>([]);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [isAdmin, setIsAdmin] = useState<boolean>(true);
  const [activeMainTab, setActiveMainTab] = useState<MainTab>('members'); // Default to members tab
  const [activeAdminSubTab, setActiveAdminSubTab] = useState<AdminSubTab>('requests');

  // Dynamic Configuration State
  const [dynamicConfig, setDynamicConfig] = useState<AppData['dynamicConfig']>(initialAppData.dynamicConfig);

  const addNotification = useCallback((notification: Omit<Notification, 'id'>) => {
    setNotifications((prev) => [...prev, { ...notification, id: Date.now() }]);
  }, []);

  useEffect(() => {
    const loadedData: AppData = loadData('scoutApp', initialAppData);
    setMembers(loadedData.members);
    setActivities(loadedData.activities);
    setFinancialRecords(loadedData.financialRecords);
    setDocuments(loadedData.documents);
    // Load dynamic config
    if (loadedData.dynamicConfig) {
      setDynamicConfig(loadedData.dynamicConfig);
    }
  }, []);

  useEffect(() => {
    saveData('scoutApp', { members, activities, financialRecords, documents, dynamicConfig });
  }, [members, activities, financialRecords, documents, dynamicConfig]);

  const toggleAdminMode = useCallback(() => setIsAdmin((prev) => !prev), []);

  const getUnitIcon = useCallback((unit: Unit) => {
    switch (unit) {
      case 'الأشبال': return '🌟'; // الأشبال
      case 'الزهرات': return '🌸'; // الزهرات
      case 'الكشافة': return '⚜️'; // الكشافة
      case 'المرشدات': return '🧭'; // المرشدات
      case 'الجوالة': return '⛰️'; // الجوالة
      case 'الدليلات': return '🏹'; // الدليلات
      case 'العصافير': return '🐦'; // العصافير
      case 'الرابطة': return '🔗'; // الرابطة
      case 'إطار الفوج': return '👨‍💼'; // إطار الفوج
      default: return '👤';
    }
  }, []);

  const contextValue: AppContextType = {
    members,
    setMembers,
    activities,
    setActivities,
    financialRecords,
    setFinancialRecords,
    documents,
    setDocuments,
    addNotification,
    isAdmin,
    toggleAdminMode,
    getUnitIcon,
    dynamicConfig,
    setDynamicConfig,
  };

  // Fixed 'Cannot find namespace JSX' error by explicitly using React.JSX.Element
  const mainTabs: { id: MainTab; label: string; component: React.JSX.Element }[] = [
    { id: 'members', label: 'إدارة المنخرطين', component: <MemberManagement /> },
    { id: 'training', label: 'المستوى التدريبي', component: <TrainingLevelTracking /> },
    { id: 'activities', label: 'إدارة الأنشطة', component: <ActivitiesManagement /> },
    { id: 'finance', label: 'إدارة المالية', component: <FinancialManagement /> },
    {
      id: 'admin',
      label: 'مكتب الضبط',
      component: (
        <div className="flex flex-col">
          <nav className="flex overflow-x-auto whitespace-nowrap mb-4 p-2 bg-neumorphic-bg rounded-xl shadow-neumorphic-out">
            <NeumorphicButton
              onClick={() => setActiveAdminSubTab('requests')}
              className={`flex-shrink-0 mx-1 px-4 py-2 text-sm font-bold transition-all duration-200 ${
                activeAdminSubTab === 'requests' ? 'bg-neumorphic-primary text-white shadow-neumorphic-button-in' : 'bg-neumorphic-bg text-gray-700 hover:shadow-neumorphic-button-out'
              }`}
              variant={activeAdminSubTab === 'requests' ? 'primary' : 'secondary'}
              type="button"
              aria-selected={activeAdminSubTab === 'requests'}
              role="tab"
            >
              الطلبات الإدارية
            </NeumorphicButton>
            <NeumorphicButton
              onClick={() => setActiveAdminSubTab('settings')}
              className={`flex-shrink-0 mx-1 px-4 py-2 text-sm font-bold transition-all duration-200 ${
                activeAdminSubTab === 'settings' ? 'bg-neumorphic-primary text-white shadow-neumorphic-button-in' : 'bg-neumorphic-bg text-gray-700 hover:shadow-neumorphic-button-out'
              }`}
              variant={activeAdminSubTab === 'settings' ? 'primary' : 'secondary'}
              type="button"
              aria-selected={activeAdminSubTab === 'settings'}
              role="tab"
            >
              إدارة الإعدادات
            </NeumorphicButton>
          </nav>
          {activeAdminSubTab === 'requests' && <AdministrativeRequests />}
          {activeAdminSubTab === 'settings' && <SettingsManagement />}
        </div>
      ),
    },
  ];

  return (
    <AppContext.Provider value={contextValue}>
      <div className="min-h-screen bg-neumorphic-bg text-gray-800 p-4 flex flex-col">
        <Navbar />

        {/* Tab Navigation */}
        <nav className="flex overflow-x-auto whitespace-nowrap mb-6 p-2 bg-neumorphic-bg rounded-xl shadow-neumorphic-out">
          {mainTabs.map((tab) => (
            <NeumorphicButton
              key={tab.id}
              onClick={() => {
                setActiveMainTab(tab.id);
                // Reset admin sub-tab when main admin tab is clicked
                if (tab.id === 'admin') {
                  setActiveAdminSubTab('requests');
                }
              }}
              className={`flex-shrink-0 mx-1 px-6 py-3 text-lg font-bold transition-all duration-200 ${
                activeMainTab === tab.id ? 'bg-neumorphic-primary text-white shadow-neumorphic-button-in' : 'bg-neumorphic-bg text-gray-700 hover:shadow-neumorphic-button-out'
              }`}
              variant={activeMainTab === tab.id ? 'primary' : 'secondary'}
              type="button"
              aria-selected={activeMainTab === tab.id}
              role="tab"
            >
              {tab.label}
            </NeumorphicButton>
          ))}
        </nav>

        <main className="flex-grow p-4 bg-neumorphic-bg rounded-xl shadow-neumorphic-out">
          {mainTabs.find(tab => tab.id === activeMainTab)?.component}
        </main>

        <div className="fixed bottom-4 left-1/2 -translate-x-1/2 flex flex-col space-y-2 z-50">
          {notifications.map((notification) => (
            <NotificationToast
              key={notification.id}
              id={notification.id}
              message={notification.message}
              type={notification.type}
              onClose={() => setNotifications(prev => prev.filter(n => n.id !== notification.id))}
            />
          ))}
        </div>
      </div>
    </AppContext.Provider>
  );
}

export default App;